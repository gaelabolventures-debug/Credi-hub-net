/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#0F2038',
          light: '#16304F',
          50: '#EAF0F6',
        },
        paper: {
          DEFAULT: '#F6F4EE',
          dim: '#EFEBE1',
        },
        line: '#DFD8C7',
        gold: {
          DEFAULT: '#B8823D',
          light: '#D7A85E',
          dark: '#8F631E',
        },
        teal: {
          DEFAULT: '#2F6B5C',
          light: '#DCEAE4',
          dark: '#1E4A3F',
        },
        danger: {
          DEFAULT: '#A23B3B',
          light: '#F5E1DF',
        },
      },
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        sans: ['"IBM Plex Sans"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(15,32,56,0.06), 0 1px 1px rgba(15,32,56,0.04)',
        panel: '0 4px 24px rgba(15,32,56,0.08)',
      },
      borderRadius: {
        sm: '4px',
        DEFAULT: '6px',
        md: '8px',
        lg: '10px',
      },
    },
  },
  plugins: [],
}

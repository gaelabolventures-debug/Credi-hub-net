import { AppStateProvider, useAppState } from './context/AppState';
import { Sidebar } from './components/Sidebar';
import { DemoScenarioOverlay } from './components/DemoScenarioOverlay';
import { Landing } from './pages/Landing';
import { Dashboard } from './pages/Dashboard';
import { Businesses } from './pages/Businesses';
import { Suppliers } from './pages/Suppliers';
import { BusinessProfile } from './pages/BusinessProfile';
import { Transactions } from './pages/Transactions';
import { Repayments } from './pages/Repayments';
import { TrustScore } from './pages/TrustScore';
import { CreditRequests } from './pages/CreditRequests';
import { Notifications } from './pages/Notifications';
import { Settings } from './pages/Settings';
import { Admin } from './pages/Admin';

function Shell() {
  const { page } = useAppState();

  if (page === 'landing') {
    return (
      <>
        <Landing />
        <DemoScenarioOverlay />
      </>
    );
  }

  const pages: Record<string, React.ReactNode> = {
    dashboard: <Dashboard />,
    businesses: <Businesses />,
    suppliers: <Suppliers />,
    'business-profile': <BusinessProfile />,
    credit: <CreditRequests />,
    transactions: <Transactions />,
    repayments: <Repayments />,
    'trust-score': <TrustScore />,
    requests: <CreditRequests />,
    notifications: <Notifications />,
    settings: <Settings />,
    admin: <Admin />,
  };

  return (
    <div className="flex min-h-screen bg-paper">
      <Sidebar />
      <main className="flex-1 min-w-0">{pages[page] || <Dashboard />}</main>
      <DemoScenarioOverlay />
    </div>
  );
}

export default function App() {
  return (
    <AppStateProvider>
      <Shell />
    </AppStateProvider>
  );
}

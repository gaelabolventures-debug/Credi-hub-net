import type { Lead } from '../types';

// ---------------------------------------------------------------------------
// GOOGLE FORM CONFIG
// ---------------------------------------------------------------------------
// To connect a real Google Form:
//   1. Create a Google Form with these fields (short answer unless noted):
//      Name, Organization, Type (multiple choice: Supplier / Business /
//      Bank or Financial Institution / Investor / Other), Email, Phone,
//      City, Note (paragraph).
//   2. Open the live form, click the three-dot menu → "Get pre-filled link".
//   3. Fill in dummy values in each field so you can identify them, click
//      "Get link", then open that link and view page source (or just look
//      at the URL — each field appears as entry.XXXXXXXXX=value).
//   4. Copy the base form URL and replace it with .../formResponse instead
//      of /viewform, and paste each entry.XXXXXXXXX id below.
// Until this is filled in, submissions are still saved locally in the
// browser (and visible in Admin → Interest Requests) so nothing is lost.
// ---------------------------------------------------------------------------

export const GOOGLE_FORM_CONFIG = {
  formActionUrl: '', // e.g. 'https://docs.google.com/forms/d/e/1FAIpQLSf.../formResponse'
  entryIds: {
    name: '', // e.g. 'entry.123456789'
    organization: '',
    type: '',
    email: '',
    phone: '',
    city: '',
    note: '',
  },
};

export function isGoogleFormConfigured(): boolean {
  return GOOGLE_FORM_CONFIG.formActionUrl.length > 0 && GOOGLE_FORM_CONFIG.entryIds.name.length > 0;
}

const STORAGE_KEY = 'credihub_leads';

export function getStoredLeads(): Lead[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Lead[]) : [];
  } catch {
    return [];
  }
}

function saveLeadLocally(lead: Lead) {
  const existing = getStoredLeads();
  existing.unshift(lead);
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(existing));
}

export interface LeadInput {
  name: string;
  organization: string;
  type: Lead['type'];
  email: string;
  phone?: string;
  city?: string;
  note?: string;
}

export async function submitLead(input: LeadInput): Promise<{ success: boolean; sentToGoogleForm: boolean }> {
  const lead: Lead = {
    id: `LEAD-${Date.now()}`,
    submittedAt: new Date().toISOString(),
    ...input,
  };

  saveLeadLocally(lead);

  if (!isGoogleFormConfigured()) {
    return { success: true, sentToGoogleForm: false };
  }

  const body = new URLSearchParams();
  const ids = GOOGLE_FORM_CONFIG.entryIds;
  if (ids.name) body.append(ids.name, input.name);
  if (ids.organization) body.append(ids.organization, input.organization);
  if (ids.type) body.append(ids.type, input.type);
  if (ids.email) body.append(ids.email, input.email);
  if (ids.phone && input.phone) body.append(ids.phone, input.phone);
  if (ids.city && input.city) body.append(ids.city, input.city);
  if (ids.note && input.note) body.append(ids.note, input.note);

  try {
    // Google Forms does not return CORS headers, so the response is opaque.
    // 'no-cors' mode still delivers the POST; we treat the attempt as success.
    await fetch(GOOGLE_FORM_CONFIG.formActionUrl, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    });
    return { success: true, sentToGoogleForm: true };
  } catch {
    return { success: true, sentToGoogleForm: false };
  }
}

export function formatETB(amount: number): string {
  const rounded = Math.round(amount);
  return `ETB ${rounded.toLocaleString('en-US')}`;
}

export function formatCompactETB(amount: number): string {
  if (Math.abs(amount) >= 1_000_000) {
    return `ETB ${(amount / 1_000_000).toFixed(1)}M`;
  }
  if (Math.abs(amount) >= 1_000) {
    return `ETB ${(amount / 1_000).toFixed(0)}K`;
  }
  return formatETB(amount);
}

export function formatDate(iso: string): string {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function formatDateShort(iso: string): string {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function timeAgo(iso: string): string {
  const then = new Date(iso + 'T00:00:00').getTime();
  const now = Date.now();
  const days = Math.floor((now - then) / (1000 * 60 * 60 * 24));
  if (days <= 0) return 'Today';
  if (days === 1) return '1 day ago';
  if (days < 30) return `${days} days ago`;
  const months = Math.floor(days / 30);
  return `${months} month${months > 1 ? 's' : ''} ago`;
}

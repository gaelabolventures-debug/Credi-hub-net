import { useAppState } from '../context/AppState';
import { TopBar } from '../components/TopBar';
import { Card, MetricCard, StatusBadge, ProgressBar, SectionLabel } from '../components/ui';
import { businesses, findSupplier, agreementsForBusiness } from '../data/mockData';
import { formatETB, formatDate } from '../lib/format';
import { PlusCircle } from 'lucide-react';

export function BusinessDashboard() {
  const { currentBusinessId, setCurrentBusinessId, navigate } = useAppState();
  const business = businesses.find((b) => b.id === currentBusinessId) || businesses[0];
  const myAgreements = agreementsForBusiness(business.id);

  const totalLimit = myAgreements.reduce((s, a) => s + a.creditLimit, 0);
  const totalUsed = myAgreements.reduce((s, a) => s + a.used, 0);
  const availableCredit = totalLimit - totalUsed;
  const nextRepayment = myAgreements
    .slice()
    .sort((a, b) => (a.nextExpectedRepayment < b.nextExpectedRepayment ? -1 : 1))[0];
  const overallRepaymentPct = totalUsed > 0
    ? Math.round((myAgreements.reduce((s, a) => s + Math.round((a.used * a.repaymentRate) / 100), 0) / totalUsed) * 100)
    : 0;

  return (
    <div>
      <TopBar title="Business Dashboard" subtitle={`Viewing credit profile for ${business.name}`} />
      <div className="px-8 py-8 max-w-6xl">
        <div className="flex items-center gap-3 mb-8">
          <label className="text-xs uppercase tracking-wide text-ink/45 font-semibold">Viewing as</label>
          <select
            value={currentBusinessId}
            onChange={(e) => setCurrentBusinessId(e.target.value)}
            className="border border-line rounded-sm px-3 py-1.5 text-sm bg-white font-sans"
          >
            {businesses.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </div>

        <SectionLabel>Credit overview</SectionLabel>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <MetricCard label="Available credit" value={formatETB(availableCredit)} accent="teal" />
          <MetricCard label="Outstanding supplier credit" value={formatETB(business.outstanding)} accent="gold" />
          <MetricCard label="Total credit limit" value={formatETB(totalLimit)} />
          <MetricCard label="Next expected repayment" value={nextRepayment ? formatDate(nextRepayment.nextExpectedRepayment) : '—'} />
        </div>
        <Card className="p-5 mb-10">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-ink/70">Overall repayment progress</span>
            <span className="font-mono font-tabular text-sm font-semibold">{overallRepaymentPct}%</span>
          </div>
          <ProgressBar percent={overallRepaymentPct} />
        </Card>

        <div className="flex items-center justify-between mb-4">
          <SectionLabel>Credit accounts</SectionLabel>
        </div>
        <div className="grid gap-4 mb-8">
          {myAgreements.map((agr) => {
            const supplier = findSupplier(agr.supplierId)!;
            return (
              <Card key={agr.id} className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="text-xs text-ink/45 uppercase tracking-wide mb-1">Supplier</div>
                    <div className="font-sans font-semibold text-ink">{supplier.name}</div>
                    <div className="text-xs text-ink/45 mt-0.5">{supplier.category}</div>
                  </div>
                  <StatusBadge status={agr.status} />
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-5">
                  <Field label="Credit limit" value={formatETB(agr.creditLimit)} />
                  <Field label="Used" value={formatETB(agr.used)} />
                  <Field label="Remaining" value={formatETB(agr.remaining)} />
                  <Field label="Repayment" value={`${agr.repaymentRate}%`} />
                </div>
                <div className="mt-4">
                  <ProgressBar percent={agr.repaymentRate} color={agr.status === 'overdue' ? 'danger' : 'teal'} />
                </div>
              </Card>
            );
          })}
        </div>

        <button
          onClick={() => navigate('requests')}
          className="inline-flex items-center gap-2 bg-ink text-white font-sans font-medium text-sm px-4 py-2.5 rounded-sm hover:bg-ink-light transition-colors"
        >
          <PlusCircle size={16} /> Request More Credit
        </button>
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[11px] text-ink/45 uppercase tracking-wide">{label}</div>
      <div className="font-mono font-tabular text-sm font-semibold mt-0.5">{value}</div>
    </div>
  );
}

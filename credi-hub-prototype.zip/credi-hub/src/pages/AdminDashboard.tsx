import { TopBar } from '../components/TopBar';
import { Card, MetricCard, StatusBadge, SectionLabel } from '../components/ui';
import { platformMetrics, suppliers, businesses } from '../data/mockData';
import { formatCompactETB, formatETB } from '../lib/format';
import { useAppState } from '../context/AppState';

export function AdminDashboard() {
  const { navigate, selectBusiness } = useAppState();
  return (
    <div>
      <TopBar title="Platform Dashboard" subtitle="Aggregate view across all suppliers and businesses" />
      <div className="px-8 py-8 max-w-6xl">
        <SectionLabel>Top metrics</SectionLabel>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-10">
          <MetricCard label="Total supplier credit" value={formatCompactETB(platformMetrics.totalSupplierCredit)} />
          <MetricCard label="Outstanding credit" value={formatCompactETB(platformMetrics.outstanding)} accent="gold" />
          <MetricCard label="Repaid" value={formatCompactETB(platformMetrics.repaid)} accent="teal" />
          <MetricCard label="Available credit" value={formatCompactETB(platformMetrics.availableCredit)} />
          <MetricCard label="Repayment rate" value={`${platformMetrics.repaymentRate}%`} accent="teal" />
          <MetricCard label="Avg. trust score" value={`${platformMetrics.trustScore}/100`} />
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <SectionLabel>Suppliers</SectionLabel>
            <Card className="overflow-hidden">
              <table className="w-full text-sm font-sans">
                <thead>
                  <tr className="border-b border-line bg-paper-dim/40 text-left text-ink/50 text-xs uppercase tracking-wide">
                    <th className="px-4 py-3 font-medium">Supplier</th>
                    <th className="px-4 py-3 font-medium">Outstanding</th>
                    <th className="px-4 py-3 font-medium">Risk</th>
                  </tr>
                </thead>
                <tbody>
                  {suppliers.map((s) => (
                    <tr key={s.id} className="border-b border-line last:border-0 hover:bg-paper-dim/30 cursor-pointer" onClick={() => navigate('suppliers')}>
                      <td className="px-4 py-3 font-medium">{s.name}</td>
                      <td className="px-4 py-3 font-mono font-tabular">{formatETB(s.totalOutstanding)}</td>
                      <td className="px-4 py-3">
                        <StatusBadge status={s.portfolioRisk === 'Low' ? 'active' : s.portfolioRisk === 'Elevated' ? 'overdue' : 'under_review'} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>
          <div>
            <SectionLabel>Businesses</SectionLabel>
            <Card className="overflow-hidden">
              <table className="w-full text-sm font-sans">
                <thead>
                  <tr className="border-b border-line bg-paper-dim/40 text-left text-ink/50 text-xs uppercase tracking-wide">
                    <th className="px-4 py-3 font-medium">Business</th>
                    <th className="px-4 py-3 font-medium">Trust</th>
                    <th className="px-4 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {businesses.map((b) => (
                    <tr key={b.id} className="border-b border-line last:border-0 hover:bg-paper-dim/30 cursor-pointer" onClick={() => selectBusiness(b.id)}>
                      <td className="px-4 py-3 font-medium">{b.name}</td>
                      <td className="px-4 py-3 font-mono font-tabular">{b.trustScore}</td>
                      <td className="px-4 py-3">
                        <StatusBadge status={b.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

import { TopBar } from '../components/TopBar';
import { Card, StatusBadge } from '../components/ui';
import { suppliers } from '../data/mockData';
import { formatETB } from '../lib/format';

export function Suppliers() {
  return (
    <div>
      <TopBar title="Suppliers" subtitle="All suppliers extending trade credit through Credi Hub" />
      <div className="px-8 py-8 max-w-6xl">
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm font-sans">
              <thead>
                <tr className="border-b border-line bg-paper-dim/40 text-left text-ink/50 text-xs uppercase tracking-wide">
                  <th className="px-5 py-3 font-medium">Supplier</th>
                  <th className="px-5 py-3 font-medium">Category</th>
                  <th className="px-5 py-3 font-medium">City</th>
                  <th className="px-5 py-3 font-medium">Total Financed</th>
                  <th className="px-5 py-3 font-medium">Outstanding</th>
                  <th className="px-5 py-3 font-medium">Avg. Repayment</th>
                  <th className="px-5 py-3 font-medium">Portfolio Risk</th>
                </tr>
              </thead>
              <tbody>
                {suppliers.map((s) => (
                  <tr key={s.id} className="border-b border-line last:border-0 hover:bg-paper-dim/30">
                    <td className="px-5 py-3.5 font-medium text-ink">{s.name}</td>
                    <td className="px-5 py-3.5 text-ink/60">{s.category}</td>
                    <td className="px-5 py-3.5 text-ink/60">{s.city}</td>
                    <td className="px-5 py-3.5 font-mono font-tabular">{formatETB(s.totalFinanced)}</td>
                    <td className="px-5 py-3.5 font-mono font-tabular">{formatETB(s.totalOutstanding)}</td>
                    <td className="px-5 py-3.5 font-mono font-tabular">{s.avgRepaymentRate}%</td>
                    <td className="px-5 py-3.5">
                      <StatusBadge status={s.portfolioRisk === 'Low' ? 'active' : s.portfolioRisk === 'Elevated' ? 'overdue' : 'under_review'} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}

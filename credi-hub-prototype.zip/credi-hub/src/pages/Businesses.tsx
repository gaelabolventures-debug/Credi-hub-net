import { TopBar } from '../components/TopBar';
import { Card, StatusBadge } from '../components/ui';
import { businesses } from '../data/mockData';
import { formatETB } from '../lib/format';
import { useAppState } from '../context/AppState';

export function Businesses() {
  const { selectBusiness } = useAppState();
  return (
    <div>
      <TopBar title="Businesses" subtitle="All businesses with an active or past credit relationship on Credi Hub" />
      <div className="px-8 py-8 max-w-6xl">
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm font-sans">
              <thead>
                <tr className="border-b border-line bg-paper-dim/40 text-left text-ink/50 text-xs uppercase tracking-wide">
                  <th className="px-5 py-3 font-medium">Business</th>
                  <th className="px-5 py-3 font-medium">Industry</th>
                  <th className="px-5 py-3 font-medium">City</th>
                  <th className="px-5 py-3 font-medium">Credit Limit</th>
                  <th className="px-5 py-3 font-medium">Outstanding</th>
                  <th className="px-5 py-3 font-medium">Trust Score</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {businesses.map((b) => (
                  <tr key={b.id} className="border-b border-line last:border-0 hover:bg-paper-dim/30 cursor-pointer" onClick={() => selectBusiness(b.id)}>
                    <td className="px-5 py-3.5 font-medium text-ink">{b.name}</td>
                    <td className="px-5 py-3.5 text-ink/60">{b.industry}</td>
                    <td className="px-5 py-3.5 text-ink/60">{b.city}</td>
                    <td className="px-5 py-3.5 font-mono font-tabular">{formatETB(b.totalCreditLimit)}</td>
                    <td className="px-5 py-3.5 font-mono font-tabular">{formatETB(b.outstanding)}</td>
                    <td className="px-5 py-3.5 font-mono font-tabular">{b.trustScore}</td>
                    <td className="px-5 py-3.5">
                      <StatusBadge status={b.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}

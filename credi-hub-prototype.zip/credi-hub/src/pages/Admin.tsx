import { useEffect, useState } from 'react';
import { Users, Truck, Receipt, FileStack, Wallet, Mail, Phone, Building2 } from 'lucide-react';
import { TopBar } from '../components/TopBar';
import { Card, MetricCard, SectionLabel } from '../components/ui';
import { businesses, suppliers, transactions, agreements, repayments } from '../data/mockData';
import { getStoredLeads, isGoogleFormConfigured } from '../lib/leadForm';
import { timeAgo } from '../lib/format';
import type { Lead } from '../types';

export function Admin() {
  const [leads, setLeads] = useState<Lead[]>([]);

  useEffect(() => {
    setLeads(getStoredLeads());
  }, []);

  const byType = leads.reduce<Record<string, number>>((acc, l) => {
    acc[l.type] = (acc[l.type] || 0) + 1;
    return acc;
  }, {});

  return (
    <div>
      <TopBar title="Admin Overview" subtitle="Platform activity and real interest requests" />
      <div className="px-8 py-8 max-w-6xl space-y-10">
        <div>
          <SectionLabel>Platform activity</SectionLabel>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <MetricCard label="Businesses" value={String(businesses.length)} icon={<Users size={16} />} />
            <MetricCard label="Suppliers" value={String(suppliers.length)} icon={<Truck size={16} />} />
            <MetricCard label="Transactions" value={String(transactions.length)} icon={<Receipt size={16} />} />
            <MetricCard label="Credit agreements" value={String(agreements.length)} icon={<FileStack size={16} />} />
            <MetricCard label="Repayment records" value={String(repayments.length)} icon={<Wallet size={16} />} />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
            <SectionLabel>Interest requests</SectionLabel>
          </div>

          <div className="flex items-center gap-2 mb-5">
            <span className={`w-2 h-2 rounded-full ${isGoogleFormConfigured() ? 'bg-teal-dark' : 'bg-gold-dark'}`} />
            <span className="text-xs text-ink/55 font-sans">
              {isGoogleFormConfigured()
                ? 'Connected to Google Form — submissions are also saved to your Google Sheet.'
                : 'Google Form not yet connected — submissions are saved locally in this browser only. See src/lib/leadForm.ts to connect one.'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-6">
            <MetricCard label="Total requests" value={String(leads.length)} />
            <MetricCard label="Suppliers" value={String(byType['Supplier'] || 0)} />
            <MetricCard label="Businesses" value={String(byType['Business'] || 0)} />
            <MetricCard label="Banks / FIs" value={String(byType['Bank / Financial Institution'] || 0)} />
            <MetricCard label="Investors" value={String(byType['Investor'] || 0)} />
          </div>

          <Card className="overflow-hidden">
            {leads.length === 0 ? (
              <div className="px-6 py-10 text-center text-sm text-ink/40">
                No interest requests yet. They'll appear here as people submit the "Request Early Access" form on the landing page.
              </div>
            ) : (
              <div className="divide-y divide-line">
                {leads.map((l) => (
                  <div key={l.id} className="px-5 py-4 flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{l.name}</span>
                        <span className="text-xs bg-paper-dim px-2 py-0.5 rounded-sm text-ink/55">{l.type}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-ink/50 mt-1">
                        <Building2 size={12} /> {l.organization} {l.city ? `· ${l.city}` : ''}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-ink/50 mt-1">
                        <span className="flex items-center gap-1"><Mail size={12} /> {l.email}</span>
                        {l.phone && <span className="flex items-center gap-1"><Phone size={12} /> {l.phone}</span>}
                      </div>
                      {l.note && <p className="text-xs text-ink/55 mt-1.5 max-w-md">{l.note}</p>}
                    </div>
                    <span className="text-xs text-ink/40">{timeAgo(l.submittedAt.slice(0, 10))}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

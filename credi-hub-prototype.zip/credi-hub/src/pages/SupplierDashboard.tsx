import { useState } from 'react';
import { Eye, CheckCircle, SlidersHorizontal, Wallet, Receipt } from 'lucide-react';
import { useAppState } from '../context/AppState';
import { TopBar } from '../components/TopBar';
import { Card, MetricCard, StatusBadge, SectionLabel } from '../components/ui';
import { suppliers, businesses, agreementsForSupplier } from '../data/mockData';
import { formatETB, formatCompactETB } from '../lib/format';

export function SupplierDashboard() {
  const { currentSupplierId, setCurrentSupplierId, selectBusiness, navigate } = useAppState();
  const supplier = suppliers.find((s) => s.id === currentSupplierId) || suppliers[0];
  const myAgreements = agreementsForSupplier(supplier.id);
  const myBusinesses = businesses.filter((b) => myAgreements.some((a) => a.businessId === b.id));
  const [toast, setToast] = useState<string | null>(null);

  const flash = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2200);
  };

  return (
    <div>
      <TopBar title="Supplier Dashboard" subtitle={`Viewing portfolio for ${supplier.name}`} />
      <div className="px-8 py-8 max-w-6xl">
        <div className="flex items-center gap-3 mb-8">
          <label className="text-xs uppercase tracking-wide text-ink/45 font-semibold">Viewing as</label>
          <select
            value={currentSupplierId}
            onChange={(e) => setCurrentSupplierId(e.target.value)}
            className="border border-line rounded-sm px-3 py-1.5 text-sm bg-white font-sans"
          >
            {suppliers.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>

        <SectionLabel>Portfolio overview</SectionLabel>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-10">
          <MetricCard label="Businesses financed" value={String(myBusinesses.length)} />
          <MetricCard label="Total outstanding" value={formatCompactETB(supplier.totalOutstanding)} accent="gold" />
          <MetricCard label="Total repayments" value={formatCompactETB(supplier.totalRepaid)} accent="teal" />
          <MetricCard label="Overdue amount" value={formatCompactETB(supplier.overdueAmount)} accent={supplier.overdueAmount > 0 ? 'danger' : 'ink'} />
          <MetricCard label="Avg. repayment rate" value={`${supplier.avgRepaymentRate}%`} />
          <MetricCard label="Portfolio risk" value={supplier.portfolioRisk} accent={supplier.portfolioRisk === 'Elevated' ? 'danger' : supplier.portfolioRisk === 'Moderate' ? 'gold' : 'teal'} />
        </div>

        <SectionLabel>Businesses</SectionLabel>
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm font-sans">
              <thead>
                <tr className="border-b border-line bg-paper-dim/40 text-left text-ink/50 text-xs uppercase tracking-wide">
                  <th className="px-5 py-3 font-medium">Business Name</th>
                  <th className="px-5 py-3 font-medium">Credit Limit</th>
                  <th className="px-5 py-3 font-medium">Outstanding</th>
                  <th className="px-5 py-3 font-medium">Repayment Rate</th>
                  <th className="px-5 py-3 font-medium">Trust Score</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {myBusinesses.map((b) => {
                  const agr = myAgreements.find((a) => a.businessId === b.id)!;
                  return (
                    <tr key={b.id} className="border-b border-line last:border-0 hover:bg-paper-dim/30">
                      <td className="px-5 py-3.5 font-medium text-ink">{b.name}</td>
                      <td className="px-5 py-3.5 font-mono font-tabular">{formatETB(agr.creditLimit)}</td>
                      <td className="px-5 py-3.5 font-mono font-tabular">{formatETB(agr.used - Math.round((agr.used * agr.repaymentRate) / 100))}</td>
                      <td className="px-5 py-3.5 font-mono font-tabular">{agr.repaymentRate}%</td>
                      <td className="px-5 py-3.5 font-mono font-tabular">{b.trustScore}</td>
                      <td className="px-5 py-3.5">
                        <StatusBadge status={agr.status} />
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center justify-end gap-1.5">
                          <IconBtn title="View Business" onClick={() => selectBusiness(b.id)}>
                            <Eye size={15} />
                          </IconBtn>
                          <IconBtn title="Approve Credit" onClick={() => navigate('requests')}>
                            <CheckCircle size={15} />
                          </IconBtn>
                          <IconBtn title="Adjust Credit Limit" onClick={() => flash(`Credit limit adjustment for ${b.name} — demo action, not persisted`)}>
                            <SlidersHorizontal size={15} />
                          </IconBtn>
                          <IconBtn title="View Repayments" onClick={() => navigate('repayments')}>
                            <Wallet size={15} />
                          </IconBtn>
                          <IconBtn title="View Transactions" onClick={() => navigate('transactions')}>
                            <Receipt size={15} />
                          </IconBtn>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      {toast && (
        <div className="fixed bottom-6 right-6 bg-ink text-white text-sm font-sans px-4 py-3 rounded-md shadow-panel max-w-xs z-50">
          {toast}
        </div>
      )}
    </div>
  );
}

function IconBtn({ children, title, onClick }: { children: React.ReactNode; title: string; onClick: () => void }) {
  return (
    <button
      title={title}
      onClick={onClick}
      className="w-8 h-8 flex items-center justify-center rounded-sm border border-line text-ink/60 hover:text-ink hover:border-ink/40 hover:bg-paper-dim/50 transition-colors"
    >
      {children}
    </button>
  );
}

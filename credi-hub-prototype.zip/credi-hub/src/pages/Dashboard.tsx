import { useAppState } from '../context/AppState';
import { SupplierDashboard } from './SupplierDashboard';
import { BusinessDashboard } from './BusinessDashboard';
import { AdminDashboard } from './AdminDashboard';

export function Dashboard() {
  const { role } = useAppState();
  if (role === 'supplier') return <SupplierDashboard />;
  if (role === 'business') return <BusinessDashboard />;
  return <AdminDashboard />;
}

import { useAppState } from '../context/AppState';
import { TopBar } from '../components/TopBar';
import { Card, ProgressBar, SectionLabel } from '../components/ui';
import { TrustScoreRing, TrustScoreBadgeLabel } from '../components/TrustScoreRing';
import { businesses } from '../data/mockData';
import { PlusCircle, MinusCircle } from 'lucide-react';

export function TrustScore() {
  const { role, currentBusinessId } = useAppState();
  const business = businesses.find((b) => b.id === currentBusinessId) || businesses[0];
  const list = role === 'supplier' ? businesses : [business];

  return (
    <div>
      <TopBar title="Trust Score" subtitle="A prototype score based on transaction and repayment behavior — not a traditional bank credit score" />
      <div className="px-8 py-8 max-w-6xl space-y-8">
        {list.map((b) => (
          <Card key={b.id} className="p-8 grid md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center md:border-r border-line md:pr-8">
              <div className="font-sans font-semibold mb-4">{b.name}</div>
              <TrustScoreRing score={b.trustScore} size={160} />
              <div className="mt-3"><TrustScoreBadgeLabel score={b.trustScore} /></div>
              <div className="text-xs text-ink/40 mt-2 font-mono">Previous: {b.trustPrevScore} → Current: {b.trustScore}</div>
            </div>

            <div className="md:col-span-2">
              <SectionLabel>Score components</SectionLabel>
              <div className="space-y-4">
                {b.trustComponents.map((c) => (
                  <div key={c.label}>
                    <div className="flex items-center justify-between text-sm mb-1.5">
                      <span className="font-medium text-ink/80">{c.label} <span className="text-ink/40 font-normal">— {c.weight}%</span></span>
                      <span className="font-mono font-tabular text-xs text-ink/50">{c.score}/100</span>
                    </div>
                    <ProgressBar percent={c.score} color={c.score >= 70 ? 'teal' : c.score >= 50 ? 'gold' : 'danger'} height="h-1.5" />
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-line">
                <div className="text-sm font-semibold text-ink mb-3">Why your score is {b.trustScore}</div>
                <ul className="space-y-2">
                  {b.trustFactors.map((f, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-ink/70">
                      {f.positive ? <PlusCircle size={15} className="text-teal-dark mt-0.5 flex-shrink-0" /> : <MinusCircle size={15} className="text-danger mt-0.5 flex-shrink-0" />}
                      {f.text}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

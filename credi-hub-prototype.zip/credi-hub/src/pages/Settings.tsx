import { useAppState } from '../context/AppState';
import { TopBar } from '../components/TopBar';
import { Card, SectionLabel } from '../components/ui';
import { businesses, suppliers } from '../data/mockData';

export function Settings() {
  const { role, setRole, currentBusinessId, setCurrentBusinessId, currentSupplierId, setCurrentSupplierId } = useAppState();

  return (
    <div>
      <TopBar title="Settings" subtitle="Demo account and identity controls" />
      <div className="px-8 py-8 max-w-xl space-y-8">
        <div>
          <SectionLabel>Role</SectionLabel>
          <Card className="p-4 flex gap-2">
            {(['supplier', 'business', 'admin'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setRole(r)}
                className={`flex-1 capitalize text-sm font-medium py-2 rounded-sm border transition-colors ${
                  role === r ? 'bg-ink text-white border-ink' : 'border-line text-ink/60 hover:bg-paper-dim/50'
                }`}
              >
                {r}
              </button>
            ))}
          </Card>
        </div>

        <div>
          <SectionLabel>Identity for this demo session</SectionLabel>
          <Card className="p-4 space-y-3">
            <div>
              <label className="text-xs text-ink/50 font-medium">Viewing as business</label>
              <select value={currentBusinessId} onChange={(e) => setCurrentBusinessId(e.target.value)} className="w-full border border-line rounded-sm px-3 py-2 text-sm bg-white mt-1">
                {businesses.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-ink/50 font-medium">Viewing as supplier</label>
              <select value={currentSupplierId} onChange={(e) => setCurrentSupplierId(e.target.value)} className="w-full border border-line rounded-sm px-3 py-2 text-sm bg-white mt-1">
                {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
          </Card>
        </div>

        <div>
          <SectionLabel>About this prototype</SectionLabel>
          <Card className="p-4 text-sm text-ink/60 leading-relaxed">
            Credi Hub is a product prototype for research and validation. It is not a licensed lender, payment
            processor, or credit bureau, and is not currently connected to any bank, payment provider, POS system,
            or government database. All data shown is simulated.
          </Card>
        </div>
      </div>
    </div>
  );
}

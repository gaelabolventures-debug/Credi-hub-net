import { useState } from 'react';
import { useAppState } from '../context/AppState';
import { TopBar } from '../components/TopBar';
import { Card, StatusBadge, SectionLabel } from '../components/ui';
import { TrustScoreRing } from '../components/TrustScoreRing';
import { creditRequests as seedRequests, findBusiness, findSupplier, suppliers, agreementsForBusiness } from '../data/mockData';
import { formatETB, formatDate } from '../lib/format';
import type { CreditRequest, CreditRequestStatus } from '../types';
import { CheckCircle, XCircle, HelpCircle } from 'lucide-react';

export function CreditRequests() {
  const { role, currentBusinessId, currentSupplierId } = useAppState();
  const [requests, setRequests] = useState<CreditRequest[]>(seedRequests);
  const [toast, setToast] = useState<string | null>(null);

  const flash = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2400);
  };

  const setStatus = (id: string, status: CreditRequestStatus) => {
    setRequests((prev) => prev.map((r) => (r.id === id ? { ...r, status } : r)));
    const label = status === 'approved' ? 'approved' : status === 'rejected' ? 'rejected' : 'sent back for more information';
    flash(`Request ${label} — demo action, not persisted`);
  };

  if (role === 'business') {
    const myRequests = requests.filter((r) => r.businessId === currentBusinessId);
    return (
      <div>
        <TopBar title="Credit Requests" subtitle="Request additional supplier credit and track review status" />
        <div className="px-8 py-8 max-w-5xl grid lg:grid-cols-2 gap-8">
          <div>
            <SectionLabel>New credit request</SectionLabel>
            <RequestForm businessId={currentBusinessId} onSubmit={() => flash('Credit request submitted — status: Under supplier review')} />
          </div>
          <div>
            <SectionLabel>Your requests</SectionLabel>
            <div className="space-y-3">
              {myRequests.map((r) => (
                <Card key={r.id} className="p-4">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <div className="font-medium text-sm">{findSupplier(r.supplierId)?.name}</div>
                      <div className="text-xs text-ink/45">{formatDate(r.submittedDate)}</div>
                    </div>
                    <StatusBadge status={r.status} />
                  </div>
                  <div className="font-mono font-tabular text-sm font-semibold">{formatETB(r.requestedAmount)}</div>
                  <p className="text-xs text-ink/55 mt-1">{r.purpose}</p>
                </Card>
              ))}
              {myRequests.length === 0 && <p className="text-sm text-ink/45">No requests yet — submit one to see it tracked here.</p>}
            </div>
          </div>
        </div>
        {toast && <Toast message={toast} />}
      </div>
    );
  }

  // supplier / admin: approval queue
  const queue = requests.filter((r) => (role === 'supplier' ? r.supplierId === currentSupplierId : true));

  return (
    <div>
      <TopBar title="Credit Requests" subtitle="Review incoming credit requests from businesses" />
      <div className="px-8 py-8 max-w-5xl space-y-5">
        {queue.map((r) => {
          const business = findBusiness(r.businessId)!;
          const existingAgreements = agreementsForBusiness(business.id);
          return (
            <Card key={r.id} className="p-6">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-5">
                <div>
                  <div className="font-sans font-semibold">{business.name}</div>
                  <div className="text-xs text-ink/45 mt-0.5">{business.industry} · {business.city} · requested {formatDate(r.submittedDate)}</div>
                </div>
                <StatusBadge status={r.status} />
              </div>

              <div className="grid md:grid-cols-4 gap-5 mb-5">
                <div className="md:col-span-1 flex flex-col items-center justify-center">
                  <TrustScoreRing score={business.trustScore} size={92} />
                </div>
                <div className="md:col-span-3 grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <Field label="Requested amount" value={formatETB(r.requestedAmount)} />
                  <Field label="Expected monthly sales" value={formatETB(r.expectedMonthlySales)} />
                  <Field label="Repayment period" value={`${r.preferredRepaymentPeriodMonths} months`} />
                  <Field label="Existing obligations" value={formatETB(business.outstanding)} />
                  <Field label="Current utilization" value={`${business.repaymentRate}% repaid`} />
                  <Field label="Sales activity" value={formatETB(business.monthlySales) + '/mo'} />
                  <Field label="Existing lines" value={String(existingAgreements.length)} />
                  <Field label="Purpose" value={r.purpose} wide />
                </div>
              </div>

              {r.additionalInfo && (
                <div className="text-xs text-ink/55 bg-paper-dim/50 rounded-sm px-3 py-2 mb-4">Note: {r.additionalInfo}</div>
              )}

              {r.status === 'under_review' || r.status === 'info_requested' ? (
                <div className="flex flex-wrap gap-2 pt-2 border-t border-line">
                  <button onClick={() => setStatus(r.id, 'approved')} className="inline-flex items-center gap-1.5 bg-teal-dark text-white text-sm font-medium px-3.5 py-2 rounded-sm hover:opacity-90 transition-opacity">
                    <CheckCircle size={15} /> Approve
                  </button>
                  <button onClick={() => setStatus(r.id, 'rejected')} className="inline-flex items-center gap-1.5 bg-white border border-line text-sm font-medium px-3.5 py-2 rounded-sm hover:bg-paper-dim/50 transition-colors">
                    <XCircle size={15} /> Reject
                  </button>
                  <button onClick={() => setStatus(r.id, 'info_requested')} className="inline-flex items-center gap-1.5 bg-white border border-line text-sm font-medium px-3.5 py-2 rounded-sm hover:bg-paper-dim/50 transition-colors">
                    <HelpCircle size={15} /> Request More Information
                  </button>
                </div>
              ) : null}
            </Card>
          );
        })}
      </div>
      {toast && <Toast message={toast} />}
    </div>
  );
}

function RequestForm({ businessId, onSubmit }: { businessId: string; onSubmit: () => void }) {
  const business = findBusiness(businessId)!;
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    supplierId: suppliers[0].id,
    amount: '',
    purpose: '',
    expectedSales: '',
    period: '3',
    info: '',
  });

  const handle = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    onSubmit();
  };

  if (submitted) {
    return (
      <Card className="p-6">
        <div className="font-semibold text-sm text-teal-dark">Credit request submitted</div>
        <div className="text-sm text-ink/60 mt-1">Status: <StatusBadge status="under_review" /></div>
        <button onClick={() => setSubmitted(false)} className="text-xs text-gold-dark mt-4 font-medium hover:underline">Submit another request</button>
      </Card>
    );
  }

  return (
    <Card className="p-5">
      <form onSubmit={handle} className="space-y-3.5">
        <div>
          <label className="text-xs text-ink/50 font-medium">Business name</label>
          <input disabled value={business.name} className="w-full border border-line rounded-sm px-3 py-2 text-sm bg-paper-dim/40 mt-1" />
        </div>
        <div>
          <label className="text-xs text-ink/50 font-medium">Supplier</label>
          <select value={form.supplierId} onChange={(e) => setForm({ ...form, supplierId: e.target.value })} className="w-full border border-line rounded-sm px-3 py-2 text-sm bg-white mt-1">
            {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs text-ink/50 font-medium">Requested amount (ETB)</label>
          <input required type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} className="w-full border border-line rounded-sm px-3 py-2 text-sm bg-white mt-1" placeholder="750000" />
        </div>
        <div>
          <label className="text-xs text-ink/50 font-medium">Purpose</label>
          <input required value={form.purpose} onChange={(e) => setForm({ ...form, purpose: e.target.value })} className="w-full border border-line rounded-sm px-3 py-2 text-sm bg-white mt-1" placeholder="Expand inventory ahead of holiday season" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-ink/50 font-medium">Expected monthly sales (ETB)</label>
            <input required type="number" value={form.expectedSales} onChange={(e) => setForm({ ...form, expectedSales: e.target.value })} className="w-full border border-line rounded-sm px-3 py-2 text-sm bg-white mt-1" />
          </div>
          <div>
            <label className="text-xs text-ink/50 font-medium">Repayment period</label>
            <select value={form.period} onChange={(e) => setForm({ ...form, period: e.target.value })} className="w-full border border-line rounded-sm px-3 py-2 text-sm bg-white mt-1">
              {[3, 4, 5, 6, 9, 12].map((m) => <option key={m} value={m}>{m} months</option>)}
            </select>
          </div>
        </div>
        <div>
          <label className="text-xs text-ink/50 font-medium">Additional information (optional)</label>
          <textarea value={form.info} onChange={(e) => setForm({ ...form, info: e.target.value })} rows={2} className="w-full border border-line rounded-sm px-3 py-2 text-sm bg-white mt-1 resize-none" />
        </div>
        <button type="submit" className="w-full bg-ink text-white font-medium text-sm py-2.5 rounded-sm hover:bg-ink-light transition-colors">
          Submit Request
        </button>
      </form>
    </Card>
  );
}

function Field({ label, value, wide = false }: { label: string; value: string; wide?: boolean }) {
  return (
    <div className={wide ? 'col-span-2 sm:col-span-4' : ''}>
      <div className="text-[11px] text-ink/45 uppercase tracking-wide">{label}</div>
      <div className="text-sm font-medium mt-0.5">{value}</div>
    </div>
  );
}

function Toast({ message }: { message: string }) {
  return (
    <div className="fixed bottom-6 right-6 bg-ink text-white text-sm font-sans px-4 py-3 rounded-md shadow-panel max-w-xs z-50">
      {message}
    </div>
  );
}

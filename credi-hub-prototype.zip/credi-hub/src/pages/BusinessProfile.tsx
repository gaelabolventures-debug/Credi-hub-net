import { ArrowLeft, MinusCircle, PlusCircle } from 'lucide-react';
import { useAppState } from '../context/AppState';
import { Card, StatusBadge, ProgressBar, SectionLabel } from '../components/ui';
import { TrustScoreRing, TrustScoreBadgeLabel } from '../components/TrustScoreRing';
import { findBusiness, agreementsForBusiness, transactionsForBusiness, findSupplier } from '../data/mockData';
import { formatETB, formatDate } from '../lib/format';

export function BusinessProfile() {
  const { selectedBusinessId, navigate, selectBusiness } = useAppState();
  const business = findBusiness(selectedBusinessId || '') || findBusiness('BUS-01')!;
  const myAgreements = agreementsForBusiness(business.id);
  const recentTx = transactionsForBusiness(business.id).slice(-6).reverse();
  const totalLimit = myAgreements.reduce((s, a) => s + a.creditLimit, 0);

  return (
    <div>
      <div className="px-8 pt-6">
        <button onClick={() => navigate('businesses')} className="inline-flex items-center gap-1.5 text-sm text-ink/50 hover:text-ink font-sans">
          <ArrowLeft size={15} /> Back to businesses
        </button>
      </div>
      <div className="px-8 py-6 border-b border-line flex flex-wrap items-start justify-between gap-6">
        <div>
          <h1 className="font-display text-2xl font-semibold">{business.name}</h1>
          <p className="text-sm text-ink/50 mt-1">{business.industry} · {business.city} · {business.yearsOperating} years operating</p>
        </div>
        <StatusBadge status={business.status} />
      </div>

      <div className="px-8 py-8 max-w-6xl grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <Card className="p-6">
            <SectionLabel>Can this business be trusted with more credit?</SectionLabel>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Field label="Monthly sales" value={formatETB(business.monthlySales)} />
              <Field label="Current credit limit" value={formatETB(totalLimit)} />
              <Field label="Outstanding obligations" value={formatETB(business.outstanding)} />
              <Field label="Repaid to date" value={formatETB(business.repaid)} />
            </div>
          </Card>

          <div>
            <SectionLabel>Main suppliers</SectionLabel>
            <div className="space-y-3">
              {myAgreements.map((a) => {
                const s = findSupplier(a.supplierId)!;
                return (
                  <Card key={a.id} className="p-4 flex items-center justify-between flex-wrap gap-3">
                    <div>
                      <div className="font-medium text-sm">{s.name}</div>
                      <div className="text-xs text-ink/45">{s.category}</div>
                    </div>
                    <div className="flex items-center gap-6">
                      <Field label="Limit" value={formatETB(a.creditLimit)} small />
                      <Field label="Repayment" value={`${a.repaymentRate}%`} small />
                      <StatusBadge status={a.status} />
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>

          <div>
            <SectionLabel>Recent transaction activity</SectionLabel>
            <Card className="divide-y divide-line">
              {recentTx.map((t) => (
                <div key={t.id} className="px-5 py-3 flex items-center justify-between text-sm">
                  <div>
                    <span className="font-medium">{formatDate(t.date)}</span>
                    <span className="text-ink/45 ml-2">Sale</span>
                  </div>
                  <span className="font-mono font-tabular">{formatETB(t.amount)}</span>
                </div>
              ))}
            </Card>
          </div>
        </div>

        <div className="space-y-6">
          <Card className="p-6 flex flex-col items-center text-center">
            <span className="text-xs uppercase tracking-wide text-ink/45 font-semibold mb-4">Credi Trust Score</span>
            <TrustScoreRing score={business.trustScore} />
            <div className="mt-3">
              <TrustScoreBadgeLabel score={business.trustScore} />
            </div>
            <button onClick={() => navigate('trust-score')} className="text-xs text-gold-dark mt-3 font-medium hover:underline">
              View full breakdown
            </button>
          </Card>

          <Card className="p-6">
            <div className="text-xs uppercase tracking-wide text-ink/45 font-semibold mb-3">Why this score</div>
            <ul className="space-y-2">
              {business.trustFactors.map((f, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-ink/70">
                  {f.positive ? <PlusCircle size={15} className="text-teal-dark mt-0.5 flex-shrink-0" /> : <MinusCircle size={15} className="text-danger mt-0.5 flex-shrink-0" />}
                  {f.text}
                </li>
              ))}
            </ul>
          </Card>

          <Card className="p-6">
            <div className="text-xs uppercase tracking-wide text-ink/45 font-semibold mb-3">Repayment progress</div>
            <ProgressBar percent={business.repaymentRate} />
            <div className="text-xs text-ink/45 mt-2">{business.repaymentRate}% repaid across all active agreements</div>
          </Card>

          <div className="flex gap-2">
            <button onClick={() => navigate('requests')} className="flex-1 bg-ink text-white text-sm font-medium py-2.5 rounded-sm hover:bg-ink-light transition-colors">
              Approve Credit
            </button>
            <button onClick={() => selectBusiness(null)} className="flex-1 border border-line text-sm font-medium py-2.5 rounded-sm hover:bg-paper-dim/50 transition-colors">
              Reject
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, small = false }: { label: string; value: string; small?: boolean }) {
  return (
    <div>
      <div className={`text-ink/45 uppercase tracking-wide ${small ? 'text-[10px]' : 'text-[11px]'}`}>{label}</div>
      <div className={`font-mono font-tabular font-semibold mt-0.5 ${small ? 'text-xs' : 'text-sm'}`}>{value}</div>
    </div>
  );
}

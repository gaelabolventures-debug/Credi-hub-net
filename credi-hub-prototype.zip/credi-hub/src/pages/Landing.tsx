import { ArrowRight, TrendingUp, ShieldCheck, Eye, Landmark } from 'lucide-react';
import { useAppState } from '../context/AppState';
import { LedgerFlow } from '../components/LedgerFlow';
import { LeadForm } from '../components/LeadForm';
import { platformMetrics } from '../data/mockData';
import { formatCompactETB } from '../lib/format';

export function Landing() {
  const { navigate, setRole } = useAppState();

  const enterDemo = (role: 'supplier' | 'business' | 'admin') => {
    setRole(role);
    navigate('dashboard');
  };

  return (
    <div className="bg-paper text-ink font-sans">
      {/* Nav */}
      <div className="max-w-6xl mx-auto px-6 lg:px-8 flex items-center justify-between py-6">
        <div className="flex items-center gap-2.5">
          <svg width="24" height="24" viewBox="0 0 32 32">
            <rect width="32" height="32" rx="6" fill="#0F2038" />
            <path d="M8 20 L14 12 L18 17 L24 9" stroke="#D7A85E" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="font-display font-semibold text-lg">Credi Hub</span>
          <span className="text-[10px] uppercase tracking-wide text-gold-dark bg-[#F6EBD9] px-2 py-0.5 rounded-sm ml-1">Demo</span>
        </div>
        <button
          onClick={() => enterDemo('supplier')}
          className="text-sm font-medium border border-ink/20 px-4 py-2 rounded-sm hover:bg-ink hover:text-white transition-colors"
        >
          Explore Demo
        </button>
      </div>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 lg:px-8 pt-10 pb-20">
        <div className="max-w-3xl">
          <div className="text-xs uppercase tracking-widest text-gold-dark font-semibold mb-5">B2B Trade Credit Infrastructure — Ethiopia</div>
          <h1 className="font-display text-5xl md:text-6xl font-semibold leading-[1.05] tracking-tight">
            Trade credit,<br />built on trust.
          </h1>
          <p className="text-lg text-ink/65 mt-6 leading-relaxed max-w-xl">
            Credi Hub helps suppliers extend credit with greater confidence by connecting transaction visibility,
            repayment infrastructure, and business trust data.
          </p>
          <div className="flex flex-wrap items-center gap-3 mt-8">
            <button
              onClick={() => enterDemo('supplier')}
              className="inline-flex items-center gap-2 bg-ink text-white font-medium px-5 py-3 rounded-sm hover:bg-ink-light transition-colors"
            >
              Explore Demo <ArrowRight size={16} />
            </button>
            <a href="#how-it-works" className="inline-flex items-center gap-2 border border-ink/20 font-medium px-5 py-3 rounded-sm hover:bg-white transition-colors">
              See How It Works
            </a>
          </div>
        </div>

        {/* Signature ledger flow */}
        <div className="mt-16 bg-white border border-line rounded-md shadow-panel p-8">
          <div className="flex items-center justify-between mb-6 flex-wrap gap-2">
            <span className="text-xs uppercase tracking-wide text-ink/45 font-semibold">The credit-to-trust cycle</span>
            <span className="font-mono text-xs text-ink/40">Simulated example · Demo Beverage Company → Addis Fresh Distribution</span>
          </div>
          <LedgerFlow activeStep={5} />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8 pt-6 border-t border-line">
            <Stat label="Credit extended" value="ETB 500,000" />
            <Stat label="Sales recorded" value="ETB 1,200,000" />
            <Stat label="Repaid to date" value="ETB 120,000" />
            <Stat label="Trust Score" value="74 → 79" accent />
          </div>
        </div>
      </section>

      {/* The problem */}
      <section className="bg-white border-y border-line py-20">
        <div className="max-w-6xl mx-auto px-6 lg:px-8 grid md:grid-cols-2 gap-12 items-start">
          <div>
            <span className="text-xs uppercase tracking-widest text-gold-dark font-semibold">The problem</span>
            <h2 className="font-display text-3xl font-semibold mt-3 leading-tight">
              Suppliers want to extend credit. Businesses need inventory. But trust is missing.
            </h2>
          </div>
          <p className="text-ink/65 leading-relaxed mt-1">
            Suppliers often want to sell products or raw materials to businesses on credit, but they don't have
            enough visibility into the buyer's actual business activity, or confidence that they'll be repaid.
            That uncertainty means less credit gets extended — and businesses miss out on the working capital and
            inventory they need to grow.
          </p>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="max-w-6xl mx-auto px-6 lg:px-8 py-20">
        <span className="text-xs uppercase tracking-widest text-gold-dark font-semibold">How Credi Hub works</span>
        <h2 className="font-display text-3xl font-semibold mt-3 mb-10">A repayment loop suppliers can see end to end.</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <FlowCard n="1" title="Supplier approves credit" text="A supplier reviews a business's trust score, sales activity, and existing obligations, then sets a credit limit." />
          <FlowCard n="2" title="Business sells, Credi Hub watches" text="As the business generates sales, Credi Hub records transaction activity — visible to both sides in real time." />
          <FlowCard n="3" title="Repayment happens automatically" text="A predefined share of eligible sales is allocated toward repayment, shrinking the outstanding balance." />
          <FlowCard n="4" title="Trust history grows" text="Consistent repayment and healthy sales activity raise the business's Credi Trust Score over time." />
          <FlowCard n="5" title="Future credit gets easier" text="A stronger trust score and clean repayment history make the next credit decision faster to evaluate." />
          <FlowCard n="6" title="Suppliers stay informed" text="Outstanding balances, overdue accounts, and portfolio risk are visible on one dashboard — no guesswork." />
        </div>
      </section>

      {/* Audiences */}
      <section className="bg-ink text-white py-20">
        <div className="max-w-6xl mx-auto px-6 lg:px-8 grid md:grid-cols-2 gap-10">
          <div className="bg-white/5 border border-white/10 rounded-md p-8">
            <TrendingUp className="text-gold-light mb-4" size={26} />
            <h3 className="font-display text-2xl font-semibold">For Suppliers</h3>
            <ul className="mt-4 space-y-2 text-white/70 text-sm leading-relaxed">
              <li>Reduce repayment uncertainty with real transaction visibility.</li>
              <li>Monitor outstanding credit and overdue accounts in one place.</li>
              <li>Understand business performance before extending more credit.</li>
            </ul>
            <button onClick={() => enterDemo('supplier')} className="mt-6 text-sm font-medium text-gold-light inline-flex items-center gap-1.5 hover:gap-2.5 transition-all">
              View supplier dashboard <ArrowRight size={14} />
            </button>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-md p-8">
            <Landmark className="text-gold-light mb-4" size={26} />
            <h3 className="font-display text-2xl font-semibold">For Businesses</h3>
            <ul className="mt-4 space-y-2 text-white/70 text-sm leading-relaxed">
              <li>Access supplier credit to stock inventory and working capital.</li>
              <li>Build a transaction and repayment history that compounds.</li>
              <li>Unlock larger credit limits over time as trust grows.</li>
            </ul>
            <button onClick={() => enterDemo('business')} className="mt-6 text-sm font-medium text-gold-light inline-flex items-center gap-1.5 hover:gap-2.5 transition-all">
              View business dashboard <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </section>

      {/* Trust + platform snapshot */}
      <section className="max-w-6xl mx-auto px-6 lg:px-8 py-20">
        <div className="grid md:grid-cols-3 gap-10 items-center">
          <div className="md:col-span-1">
            <span className="text-xs uppercase tracking-widest text-gold-dark font-semibold">Built for scrutiny</span>
            <h2 className="font-display text-3xl font-semibold mt-3 leading-tight">Not a lender. A trust layer.</h2>
            <p className="text-ink/65 mt-4 leading-relaxed text-sm">
              Credi Hub doesn't finance transactions in this version — it gives suppliers the workflow, visibility,
              and trust scoring to extend their own credit with confidence. Financing partnerships can come later.
            </p>
          </div>
          <div className="md:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-4">
            <MiniMetric icon={<ShieldCheck size={16} />} label="Avg. trust score" value={`${platformMetrics.trustScore} / 100`} />
            <MiniMetric icon={<Eye size={16} />} label="Repayment rate" value={`${platformMetrics.repaymentRate}%`} />
            <MiniMetric icon={<TrendingUp size={16} />} label="Total credit tracked" value={formatCompactETB(platformMetrics.totalSupplierCredit)} />
            <MiniMetric icon={<TrendingUp size={16} />} label="Outstanding" value={formatCompactETB(platformMetrics.outstanding)} />
            <MiniMetric icon={<TrendingUp size={16} />} label="Repaid" value={formatCompactETB(platformMetrics.repaid)} />
            <MiniMetric icon={<TrendingUp size={16} />} label="Available credit" value={formatCompactETB(platformMetrics.availableCredit)} />
          </div>
        </div>
        <p className="text-xs text-ink/40 mt-6">All figures are simulated demo data for illustration, not live financial records.</p>
      </section>

      {/* Early access */}
      <section id="early-access" className="bg-white border-t border-line py-20">
        <div className="max-w-3xl mx-auto px-6 lg:px-8">
          <span className="text-xs uppercase tracking-widest text-gold-dark font-semibold">Request early access</span>
          <h2 className="font-display text-3xl font-semibold mt-3 mb-2">Considering this for your business?</h2>
          <p className="text-ink/60 mb-8 text-sm">
            Whether you're a supplier, a business buying on credit, or a financial institution exploring this space —
            leave your details and we'll follow up.
          </p>
          <LeadForm />
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-6xl mx-auto px-6 lg:px-8 py-10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-ink/40">
        <span>Credi Hub — Prototype / Demo. Not a licensed lender, payment processor, or credit bureau.</span>
        <span>© 2026 Credi Hub. Fictional demo data throughout.</span>
      </footer>
    </div>
  );
}

function Stat({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) {
  return (
    <div>
      <div className="text-xs text-ink/45 uppercase tracking-wide">{label}</div>
      <div className={`font-mono font-tabular text-lg font-semibold mt-1 ${accent ? 'text-teal-dark' : 'text-ink'}`}>{value}</div>
    </div>
  );
}

function FlowCard({ n, title, text }: { n: string; title: string; text: string }) {
  return (
    <div className="bg-white border border-line rounded-md p-6">
      <span className="font-mono text-xs text-gold-dark">{n.padStart(2, '0')}</span>
      <h4 className="font-sans font-semibold mt-2">{title}</h4>
      <p className="text-sm text-ink/60 mt-2 leading-relaxed">{text}</p>
    </div>
  );
}

function MiniMetric({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="border border-line rounded-md p-4 bg-white">
      <div className="flex items-center gap-1.5 text-ink/45">
        {icon}
        <span className="text-[11px] uppercase tracking-wide">{label}</span>
      </div>
      <div className="font-mono font-tabular text-lg font-semibold mt-1.5">{value}</div>
    </div>
  );
}

import { useAppState } from '../context/AppState';
import { TopBar } from '../components/TopBar';
import { Card } from '../components/ui';
import { notifications } from '../data/mockData';
import { timeAgo } from '../lib/format';
import { CheckCircle, TrendingUp, ShieldCheck, Clock, HelpCircle, ArrowUpCircle } from 'lucide-react';

const ICONS: Record<string, React.ElementType> = {
  credit_approved: CheckCircle,
  repayment_received: TrendingUp,
  limit_increased: ArrowUpCircle,
  trust_updated: ShieldCheck,
  repayment_upcoming: Clock,
  info_requested: HelpCircle,
};

export function Notifications() {
  const { role } = useAppState();
  const list = notifications.filter((n) => n.audience === role).sort((a, b) => (a.date < b.date ? 1 : -1));

  return (
    <div>
      <TopBar title="Notifications" subtitle="Activity relevant to your account" />
      <div className="px-8 py-8 max-w-2xl">
        <Card className="divide-y divide-line">
          {list.map((n) => {
            const Icon = ICONS[n.type] || CheckCircle;
            return (
              <div key={n.id} className={`px-5 py-4 flex items-start gap-3 ${!n.read ? 'bg-[#F6EBD9]/30' : ''}`}>
                <Icon size={17} className="text-gold-dark mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm text-ink/85">{n.message}</p>
                  <span className="text-xs text-ink/40">{timeAgo(n.date)}</span>
                </div>
                {!n.read && <span className="w-2 h-2 rounded-full bg-gold-dark mt-1.5 flex-shrink-0" />}
              </div>
            );
          })}
          {list.length === 0 && <div className="px-5 py-8 text-center text-sm text-ink/40">No notifications yet.</div>}
        </Card>
      </div>
    </div>
  );
}

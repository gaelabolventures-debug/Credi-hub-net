import { useAppState } from '../context/AppState';
import { TopBar } from '../components/TopBar';
import { Card, ProgressBar, StatusBadge, SectionLabel } from '../components/ui';
import { agreements, repayments, findBusiness, findSupplier } from '../data/mockData';
import { formatETB, formatDate } from '../lib/format';

export function Repayments() {
  const { role, currentBusinessId, currentSupplierId } = useAppState();

  const myAgreements = agreements.filter((a) => {
    if (role === 'business') return a.businessId === currentBusinessId;
    if (role === 'supplier') return a.supplierId === currentSupplierId;
    return true;
  });

  return (
    <div>
      <TopBar title="Repayments" subtitle="Original credit, amount repaid, and outstanding balance per agreement" />
      <div className="px-8 py-8 max-w-6xl space-y-6">
        {myAgreements.map((a) => {
          const repaid = Math.round((a.used * a.repaymentRate) / 100);
          const outstanding = a.used - repaid;
          const history = repayments.filter((r) => r.agreementId === a.id).sort((x, y) => (x.date < y.date ? 1 : -1));
          const business = findBusiness(a.businessId)!;
          const supplier = findSupplier(a.supplierId)!;

          return (
            <Card key={a.id} className="p-6">
              <div className="flex flex-wrap items-start justify-between gap-3 mb-5">
                <div>
                  <div className="font-sans font-semibold">{business.name} <span className="text-ink/40 font-normal">→</span> {supplier.name}</div>
                  <div className="text-xs text-ink/45 mt-0.5">Next expected repayment: {formatDate(a.nextExpectedRepayment)}</div>
                </div>
                <StatusBadge status={a.status} />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                <Field label="Original credit" value={formatETB(a.used)} />
                <Field label="Total repaid" value={formatETB(repaid)} />
                <Field label="Outstanding" value={formatETB(outstanding)} />
                <Field label="Overdue amount" value={formatETB(a.overdueAmount)} danger={a.overdueAmount > 0} />
              </div>

              <div className="mb-2 flex items-center justify-between">
                <span className="text-xs text-ink/50">Repayment progress</span>
                <span className="font-mono font-tabular text-xs font-semibold">{a.repaymentRate}%</span>
              </div>
              <ProgressBar percent={a.repaymentRate} color={a.status === 'overdue' ? 'danger' : 'teal'} />

              {history.length > 0 && (
                <div className="mt-5 pt-5 border-t border-line">
                  <SectionLabel>Repayment history</SectionLabel>
                  <div className="space-y-1.5">
                    {history.map((r) => (
                      <div key={r.id} className="flex items-center justify-between text-sm">
                        <span className="text-ink/60">{formatDate(r.date)} · {r.method}</span>
                        <span className="font-mono font-tabular text-teal-dark">{formatETB(r.amount)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function Field({ label, value, danger = false }: { label: string; value: string; danger?: boolean }) {
  return (
    <div>
      <div className="text-[11px] text-ink/45 uppercase tracking-wide">{label}</div>
      <div className={`font-mono font-tabular text-sm font-semibold mt-0.5 ${danger ? 'text-danger' : 'text-ink'}`}>{value}</div>
    </div>
  );
}

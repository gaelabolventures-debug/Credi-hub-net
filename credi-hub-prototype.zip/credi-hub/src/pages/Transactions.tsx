import { useAppState } from '../context/AppState';
import { TopBar } from '../components/TopBar';
import { Card } from '../components/ui';
import { transactions, findBusiness, findSupplier } from '../data/mockData';
import { formatETB, formatDate } from '../lib/format';

export function Transactions() {
  const { role, currentBusinessId, currentSupplierId } = useAppState();

  const rows = transactions
    .filter((t) => {
      if (role === 'business') return t.businessId === currentBusinessId;
      if (role === 'supplier') return t.supplierId === currentSupplierId;
      return true;
    })
    .slice()
    .sort((a, b) => (a.date < b.date ? 1 : -1));

  return (
    <div>
      <TopBar title="Transactions" subtitle="Simulated sales activity — labeled for demonstration only" />
      <div className="px-8 py-8 max-w-6xl">
        <div className="bg-[#F6EBD9] border border-gold/30 text-gold-dark text-xs font-sans px-4 py-2.5 rounded-sm mb-6">
          These are simulated transactions for prototype purposes. Credi Hub is not connected to a live POS, bank, or payment provider.
        </div>
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm font-sans">
              <thead>
                <tr className="border-b border-line bg-paper-dim/40 text-left text-ink/50 text-xs uppercase tracking-wide">
                  <th className="px-5 py-3 font-medium">Date</th>
                  {role !== 'business' && <th className="px-5 py-3 font-medium">Business</th>}
                  {role !== 'supplier' && <th className="px-5 py-3 font-medium">Supplier</th>}
                  <th className="px-5 py-3 font-medium">Type</th>
                  <th className="px-5 py-3 font-medium">Amount</th>
                  <th className="px-5 py-3 font-medium">Repayment Allocation</th>
                  <th className="px-5 py-3 font-medium">Supplier Repayment</th>
                  <th className="px-5 py-3 font-medium">Remaining Balance</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((t) => (
                  <tr key={t.id} className="border-b border-line last:border-0 hover:bg-paper-dim/30">
                    <td className="px-5 py-3.5">{formatDate(t.date)}</td>
                    {role !== 'business' && <td className="px-5 py-3.5 text-ink/70">{findBusiness(t.businessId)?.name}</td>}
                    {role !== 'supplier' && <td className="px-5 py-3.5 text-ink/70">{findSupplier(t.supplierId)?.name}</td>}
                    <td className="px-5 py-3.5 text-ink/60">{t.type}</td>
                    <td className="px-5 py-3.5 font-mono font-tabular font-medium">{formatETB(t.amount)}</td>
                    <td className="px-5 py-3.5 text-ink/60">{t.repaymentAllocationPct}%</td>
                    <td className="px-5 py-3.5 font-mono font-tabular text-teal-dark">{formatETB(t.repaymentAmount)}</td>
                    <td className="px-5 py-3.5 font-mono font-tabular">{formatETB(t.remainingBalanceAfter)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}

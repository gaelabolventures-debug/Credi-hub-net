import { createContext, useContext, useState, type ReactNode } from 'react';
import type { Role } from '../types';

export type Page =
  | 'landing'
  | 'dashboard'
  | 'businesses'
  | 'suppliers'
  | 'business-profile'
  | 'credit'
  | 'transactions'
  | 'repayments'
  | 'trust-score'
  | 'requests'
  | 'notifications'
  | 'settings'
  | 'admin';

interface AppState {
  role: Role;
  setRole: (r: Role) => void;
  page: Page;
  navigate: (p: Page) => void;
  selectedBusinessId: string | null;
  selectBusiness: (id: string | null) => void;
  currentBusinessId: string;
  setCurrentBusinessId: (id: string) => void;
  currentSupplierId: string;
  setCurrentSupplierId: (id: string) => void;
  demoScenarioActive: boolean;
  demoScenarioStep: number;
  runDemoScenario: () => void;
  resetDemoScenario: () => void;
}

const AppStateContext = createContext<AppState | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>('supplier');
  const [page, setPage] = useState<Page>('landing');
  const [selectedBusinessId, setSelectedBusinessId] = useState<string | null>(null);
  const [currentBusinessId, setCurrentBusinessId] = useState('BUS-01');
  const [currentSupplierId, setCurrentSupplierId] = useState('SUP-01');
  const [demoScenarioActive, setDemoScenarioActive] = useState(false);
  const [demoScenarioStep, setDemoScenarioStep] = useState(0);

  const navigate = (p: Page) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const selectBusiness = (id: string | null) => {
    setSelectedBusinessId(id);
    if (id) navigate('business-profile');
  };

  const runDemoScenario = () => {
    setDemoScenarioActive(true);
    setDemoScenarioStep(0);
    const steps = [1, 2, 3, 4, 5];
    steps.forEach((_, i) => {
      setTimeout(() => setDemoScenarioStep(i + 1), (i + 1) * 900);
    });
  };

  const resetDemoScenario = () => {
    setDemoScenarioActive(false);
    setDemoScenarioStep(0);
  };

  return (
    <AppStateContext.Provider
      value={{
        role,
        setRole,
        page,
        navigate,
        selectedBusinessId,
        selectBusiness,
        currentBusinessId,
        setCurrentBusinessId,
        currentSupplierId,
        setCurrentSupplierId,
        demoScenarioActive,
        demoScenarioStep,
        runDemoScenario,
        resetDemoScenario,
      }}
    >
      {children}
    </AppStateContext.Provider>
  );
}

export function useAppState(): AppState {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useAppState must be used within AppStateProvider');
  return ctx;
}

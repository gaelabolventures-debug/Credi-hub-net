export type Role = 'supplier' | 'business' | 'admin';

export type CreditStatus = 'active' | 'overdue' | 'under_review' | 'closed';

export interface TrustComponent {
  label: string;
  weight: number; // percentage
  score: number; // 0-100 contribution quality
}

export interface TrustFactor {
  text: string;
  positive: boolean;
}

export interface Business {
  id: string;
  name: string;
  industry: string;
  yearsOperating: number;
  city: string;
  monthlySales: number;
  trustScore: number;
  trustPrevScore: number;
  trustComponents: TrustComponent[];
  trustFactors: TrustFactor[];
  totalCreditLimit: number;
  outstanding: number;
  repaid: number;
  repaymentRate: number; // percentage of on-time repayment behavior
  status: CreditStatus;
  supplierIds: string[];
}

export interface Supplier {
  id: string;
  name: string;
  category: string;
  city: string;
  yearsOperating: number;
  totalFinanced: number;
  totalOutstanding: number;
  totalRepaid: number;
  overdueAmount: number;
  avgRepaymentRate: number;
  portfolioRisk: 'Low' | 'Moderate' | 'Elevated';
  businessIds: string[];
}

export interface CreditAgreement {
  id: string;
  supplierId: string;
  businessId: string;
  creditLimit: number;
  used: number;
  remaining: number;
  repaymentAllocationPct: number; // % of eligible sales routed to repayment
  repaymentRate: number; // % of used credit repaid so far
  status: CreditStatus;
  startDate: string;
  nextExpectedRepayment: string;
  overdueAmount: number;
}

export interface Transaction {
  id: string;
  businessId: string;
  supplierId: string;
  date: string;
  amount: number;
  type: 'Sale';
  repaymentAllocationPct: number;
  repaymentAmount: number;
  remainingBalanceAfter: number;
}

export interface Repayment {
  id: string;
  agreementId: string;
  businessId: string;
  supplierId: string;
  date: string;
  amount: number;
  method: 'Sales allocation' | 'Manual settlement';
}

export type CreditRequestStatus = 'under_review' | 'approved' | 'rejected' | 'info_requested';

export interface CreditRequest {
  id: string;
  businessId: string;
  supplierId: string;
  requestedAmount: number;
  purpose: string;
  expectedMonthlySales: number;
  preferredRepaymentPeriodMonths: number;
  additionalInfo?: string;
  status: CreditRequestStatus;
  submittedDate: string;
}

export type NotificationType =
  | 'credit_approved'
  | 'repayment_received'
  | 'limit_increased'
  | 'trust_updated'
  | 'repayment_upcoming'
  | 'info_requested';

export interface AppNotification {
  id: string;
  type: NotificationType;
  message: string;
  date: string;
  read: boolean;
  audience: Role;
}

export interface Lead {
  id: string;
  name: string;
  organization: string;
  type: 'Supplier' | 'Business' | 'Bank / Financial Institution' | 'Investor' | 'Other';
  email: string;
  phone?: string;
  city?: string;
  note?: string;
  submittedAt: string;
}

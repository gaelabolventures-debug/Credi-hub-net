import { useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { submitLead, type LeadInput } from '../lib/leadForm';
import type { Lead } from '../types';

const TYPES: Lead['type'][] = ['Supplier', 'Business', 'Bank / Financial Institution', 'Investor', 'Other'];

export function LeadForm({ compact = false, defaultType }: { compact?: boolean; defaultType?: Lead['type'] }) {
  const [form, setForm] = useState<LeadInput>({
    name: '',
    organization: '',
    type: defaultType || 'Supplier',
    email: '',
    phone: '',
    city: '',
    note: '',
  });
  const [status, setStatus] = useState<'idle' | 'sending' | 'done'>('idle');

  const update = (field: keyof LeadInput) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm((f) => ({ ...f, [field]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.organization) return;
    setStatus('sending');
    await submitLead(form);
    setStatus('done');
  };

  if (status === 'done') {
    return (
      <div className="bg-teal-light border border-teal/30 rounded-md p-6 flex items-start gap-3">
        <CheckCircle2 className="text-teal-dark flex-shrink-0 mt-0.5" size={22} />
        <div>
          <div className="font-sans font-semibold text-teal-dark">Request received</div>
          <p className="text-sm text-teal-dark/80 mt-1 font-sans">
            Thanks — we'll follow up directly. You can keep exploring the demo in the meantime.
          </p>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className={`grid ${compact ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'} gap-3.5`}>
      <input
        required
        placeholder="Full name"
        value={form.name}
        onChange={update('name')}
        className="border border-line rounded-sm px-3.5 py-2.5 text-sm font-sans bg-white focus:border-ink outline-none"
      />
      <input
        required
        placeholder="Business / organization name"
        value={form.organization}
        onChange={update('organization')}
        className="border border-line rounded-sm px-3.5 py-2.5 text-sm font-sans bg-white focus:border-ink outline-none"
      />
      <select
        value={form.type}
        onChange={update('type')}
        className="border border-line rounded-sm px-3.5 py-2.5 text-sm font-sans bg-white focus:border-ink outline-none"
      >
        {TYPES.map((t) => (
          <option key={t} value={t}>
            {t}
          </option>
        ))}
      </select>
      <input
        required
        type="email"
        placeholder="Email address"
        value={form.email}
        onChange={update('email')}
        className="border border-line rounded-sm px-3.5 py-2.5 text-sm font-sans bg-white focus:border-ink outline-none"
      />
      <input
        placeholder="Phone (optional)"
        value={form.phone}
        onChange={update('phone')}
        className="border border-line rounded-sm px-3.5 py-2.5 text-sm font-sans bg-white focus:border-ink outline-none"
      />
      <input
        placeholder="City (optional)"
        value={form.city}
        onChange={update('city')}
        className="border border-line rounded-sm px-3.5 py-2.5 text-sm font-sans bg-white focus:border-ink outline-none"
      />
      <textarea
        placeholder="What are you interested in? (optional)"
        value={form.note}
        onChange={update('note')}
        rows={2}
        className={`${compact ? '' : 'sm:col-span-2'} border border-line rounded-sm px-3.5 py-2.5 text-sm font-sans bg-white focus:border-ink outline-none resize-none`}
      />
      <button
        type="submit"
        disabled={status === 'sending'}
        className={`${compact ? '' : 'sm:col-span-2'} bg-ink text-white font-sans font-medium text-sm rounded-sm py-2.5 hover:bg-ink-light transition-colors disabled:opacity-60`}
      >
        {status === 'sending' ? 'Sending…' : 'Request Early Access'}
      </button>
    </form>
  );
}

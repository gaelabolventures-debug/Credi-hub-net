interface FlowStep {
  label: string;
  detail: string;
}

const STEPS: FlowStep[] = [
  { label: 'Credit extended', detail: 'Supplier approves a limit' },
  { label: 'Inventory received', detail: 'Business draws on the line' },
  { label: 'Sales recorded', detail: 'Activity logged in Credi Hub' },
  { label: 'Repayment allocated', detail: 'Share of sales routed back' },
  { label: 'Trust updated', detail: 'Score reflects new behavior' },
];

export function LedgerFlow({ activeStep = STEPS.length, animated = false }: { activeStep?: number; animated?: boolean }) {
  return (
    <div className="w-full overflow-x-auto">
      <div className="flex items-start min-w-[560px] md:min-w-0">
        {STEPS.map((step, i) => {
          const isDone = i < activeStep;
          const isCurrent = i === activeStep - 1 && animated;
          return (
            <div key={step.label} className="flex-1 flex flex-col items-start relative">
              <div className="flex items-center w-full">
                <div
                  className={`w-3.5 h-3.5 rounded-full border-2 flex-shrink-0 z-10 transition-colors duration-500 ${
                    isDone ? 'bg-gold border-gold' : 'bg-paper border-line'
                  } ${isCurrent ? 'ring-4 ring-gold/25' : ''}`}
                />
                {i < STEPS.length - 1 && (
                  <div className="flex-1 h-px bg-line relative mx-1">
                    <div
                      className="absolute inset-y-0 left-0 bg-gold transition-all duration-700 ease-out"
                      style={{ width: isDone ? '100%' : '0%', height: '1px' }}
                    />
                  </div>
                )}
              </div>
              <div className="mt-3 pr-3">
                <div className={`font-sans text-sm font-semibold ${isDone ? 'text-ink' : 'text-ink/40'}`}>{step.label}</div>
                <div className={`font-sans text-xs mt-0.5 ${isDone ? 'text-ink/60' : 'text-ink/35'}`}>{step.detail}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

import { trustLabel } from '../data/mockData';

export function TrustScoreRing({ score, size = 140 }: { score: number; size?: number }) {
  const stroke = size * 0.09;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - score / 100);
  const color = score >= 80 ? '#2F6B5C' : score >= 65 ? '#B8823D' : score >= 50 ? '#B8823D' : '#A23B3B';

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="#EFEBE1" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 1s ease-out' }}
        />
      </svg>
      <div className="absolute flex flex-col items-center justify-center">
        <span className="font-mono font-tabular font-semibold text-ink" style={{ fontSize: size * 0.26 }}>
          {score}
        </span>
        <span className="text-[10px] uppercase tracking-wide text-ink/45 -mt-1">/ 100</span>
      </div>
    </div>
  );
}

export function TrustScoreBadgeLabel({ score }: { score: number }) {
  const color = score >= 80 ? 'text-teal-dark' : score >= 65 ? 'text-gold-dark' : score >= 50 ? 'text-gold-dark' : 'text-danger';
  return <span className={`font-sans font-semibold ${color}`}>{trustLabel(score)}</span>;
}

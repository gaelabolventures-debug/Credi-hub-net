import type { ReactNode } from 'react';

export function MetricCard({
  label,
  value,
  sublabel,
  accent = 'ink',
  icon,
}: {
  label: string;
  value: string;
  sublabel?: string;
  accent?: 'ink' | 'gold' | 'teal' | 'danger';
  icon?: ReactNode;
}) {
  const accentColor =
    accent === 'gold' ? 'text-gold-dark' : accent === 'teal' ? 'text-teal-dark' : accent === 'danger' ? 'text-danger' : 'text-ink';
  return (
    <div className="bg-white border border-line rounded-md shadow-card p-5 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wide text-ink/50 font-sans font-medium">{label}</span>
        {icon && <span className={accentColor}>{icon}</span>}
      </div>
      <span className={`font-mono font-tabular text-2xl font-semibold ${accentColor}`}>{value}</span>
      {sublabel && <span className="text-xs text-ink/50">{sublabel}</span>}
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    active: 'bg-teal-light text-teal-dark',
    Active: 'bg-teal-light text-teal-dark',
    overdue: 'bg-danger-light text-danger',
    Overdue: 'bg-danger-light text-danger',
    under_review: 'bg-amber-50 text-gold-dark bg-[#F6EBD9]',
    'Under Review': 'bg-[#F6EBD9] text-gold-dark',
    approved: 'bg-teal-light text-teal-dark',
    Approved: 'bg-teal-light text-teal-dark',
    rejected: 'bg-danger-light text-danger',
    Rejected: 'bg-danger-light text-danger',
    info_requested: 'bg-[#F6EBD9] text-gold-dark',
    'Info Requested': 'bg-[#F6EBD9] text-gold-dark',
    closed: 'bg-ink-50 text-ink/60',
    Closed: 'bg-ink-50 text-ink/60',
  };
  const label = status
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-sm text-xs font-medium font-sans ${map[status] || 'bg-ink-50 text-ink/60'}`}>
      {label}
    </span>
  );
}

export function ProgressBar({
  percent,
  color = 'teal',
  height = 'h-2',
}: {
  percent: number;
  color?: 'teal' | 'gold' | 'danger';
  height?: string;
}) {
  const barColor = color === 'gold' ? 'bg-gold' : color === 'danger' ? 'bg-danger' : 'bg-teal';
  const clamped = Math.max(0, Math.min(100, percent));
  return (
    <div className={`w-full ${height} bg-paper-dim rounded-full overflow-hidden border border-line/60`}>
      <div
        className={`${barColor} ${height} rounded-full transition-all duration-700 ease-out`}
        style={{ width: `${clamped}%` }}
      />
    </div>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <span className="text-xs uppercase tracking-wider text-ink/45 font-sans font-semibold">{children}</span>
      <span className="flex-1 h-px bg-line" />
    </div>
  );
}

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`bg-white border border-line rounded-md shadow-card ${className}`}>{children}</div>;
}

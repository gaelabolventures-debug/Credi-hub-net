import {
  LayoutDashboard,
  Building2,
  Truck,
  FileStack,
  Receipt,
  Wallet,
  ShieldCheck,
  ClipboardList,
  Bell,
  Settings as SettingsIcon,
  ShieldAlert,
  LogOut,
} from 'lucide-react';
import { useAppState, type Page } from '../context/AppState';
import { notifications } from '../data/mockData';

const NAV: { page: Page; label: string; icon: React.ElementType; roles: Array<'supplier' | 'business' | 'admin'> }[] = [
  { page: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['supplier', 'business', 'admin'] },
  { page: 'businesses', label: 'Businesses', icon: Building2, roles: ['supplier', 'admin'] },
  { page: 'suppliers', label: 'Suppliers', icon: Truck, roles: ['business', 'admin'] },
  { page: 'credit', label: 'Credit', icon: FileStack, roles: ['supplier', 'business', 'admin'] },
  { page: 'transactions', label: 'Transactions', icon: Receipt, roles: ['supplier', 'business', 'admin'] },
  { page: 'repayments', label: 'Repayments', icon: Wallet, roles: ['supplier', 'business', 'admin'] },
  { page: 'trust-score', label: 'Trust Score', icon: ShieldCheck, roles: ['supplier', 'business'] },
  { page: 'requests', label: 'Requests', icon: ClipboardList, roles: ['supplier', 'business'] },
  { page: 'notifications', label: 'Notifications', icon: Bell, roles: ['supplier', 'business', 'admin'] },
  { page: 'admin', label: 'Admin Overview', icon: ShieldAlert, roles: ['admin'] },
  { page: 'settings', label: 'Settings', icon: SettingsIcon, roles: ['supplier', 'business', 'admin'] },
];

export function Sidebar() {
  const { role, setRole, page, navigate } = useAppState();
  const unread = notifications.filter((n) => n.audience === role && !n.read).length;

  return (
    <aside className="w-60 flex-shrink-0 bg-ink text-white/90 flex flex-col h-screen sticky top-0">
      <button onClick={() => navigate('landing')} className="flex items-center gap-2.5 px-5 py-5 text-left">
        <svg width="26" height="26" viewBox="0 0 32 32" className="flex-shrink-0">
          <rect width="32" height="32" rx="6" fill="#D7A85E" />
          <path d="M8 20 L14 12 L18 17 L24 9" stroke="#0F2038" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <div>
          <div className="font-display font-semibold text-white text-lg leading-none">Credi Hub</div>
          <div className="text-[10px] text-white/40 tracking-wide mt-0.5">DEMO / PROTOTYPE</div>
        </div>
      </button>

      <nav className="flex-1 px-3 mt-2 space-y-0.5 overflow-y-auto">
        {NAV.filter((item) => item.roles.includes(role)).map((item) => {
          const Icon = item.icon;
          const active = page === item.page;
          return (
            <button
              key={item.page}
              onClick={() => navigate(item.page)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-sm font-sans transition-colors relative ${
                active ? 'bg-white/10 text-white font-medium' : 'text-white/60 hover:bg-white/5 hover:text-white/90'
              }`}
            >
              <Icon size={17} strokeWidth={1.8} />
              {item.label}
              {item.page === 'notifications' && unread > 0 && (
                <span className="ml-auto bg-gold text-ink text-[10px] font-semibold rounded-full w-4 h-4 flex items-center justify-center">
                  {unread}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="px-3 pb-4 pt-2 border-t border-white/10 mt-2">
        <div className="px-3 py-2 text-[10px] uppercase tracking-wide text-white/35 font-sans">Viewing as</div>
        <div className="flex flex-col gap-1 px-1">
          {(['supplier', 'business', 'admin'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRole(r)}
              className={`text-left px-2.5 py-1.5 rounded text-xs font-sans capitalize transition-colors ${
                role === r ? 'bg-gold/20 text-gold-light font-medium' : 'text-white/50 hover:text-white/80'
              }`}
            >
              {r === 'admin' ? 'Admin' : r}
            </button>
          ))}
        </div>
        <button
          onClick={() => navigate('landing')}
          className="w-full flex items-center gap-2 px-3 py-2 mt-2 text-xs text-white/40 hover:text-white/70 font-sans"
        >
          <LogOut size={14} /> Exit demo
        </button>
      </div>
    </aside>
  );
}

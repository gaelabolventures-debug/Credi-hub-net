import { X } from 'lucide-react';
import { useAppState } from '../context/AppState';
import { LedgerFlow } from './LedgerFlow';

export function DemoScenarioOverlay() {
  const { demoScenarioActive, demoScenarioStep, resetDemoScenario } = useAppState();
  if (!demoScenarioActive) return null;

  const repaidNow = Math.round((demoScenarioStep / 5) * 120000);
  const salesNow = Math.round((demoScenarioStep / 5) * 1200000);

  return (
    <div className="fixed inset-0 bg-ink/60 backdrop-blur-sm z-50 flex items-center justify-center p-6">
      <div className="bg-white rounded-md shadow-panel max-w-2xl w-full p-8 relative">
        <button onClick={resetDemoScenario} className="absolute top-5 right-5 text-ink/40 hover:text-ink">
          <X size={18} />
        </button>
        <span className="text-xs uppercase tracking-widest text-gold-dark font-semibold">Demo scenario</span>
        <h2 className="font-display text-2xl font-semibold mt-2">Demo Beverage Company → Addis Fresh Distribution</h2>
        <p className="text-sm text-ink/55 mt-1">ETB 500,000 credit extended · watch the cycle play out</p>

        <div className="mt-8">
          <LedgerFlow activeStep={demoScenarioStep} animated />
        </div>

        <div className="grid grid-cols-3 gap-4 mt-10 pt-6 border-t border-line">
          <div>
            <div className="text-xs text-ink/45 uppercase tracking-wide">Sales generated</div>
            <div className="font-mono font-tabular text-xl font-semibold mt-1 text-ink">ETB {salesNow.toLocaleString()}</div>
          </div>
          <div>
            <div className="text-xs text-ink/45 uppercase tracking-wide">Repaid (10% allocation)</div>
            <div className="font-mono font-tabular text-xl font-semibold mt-1 text-teal-dark">ETB {repaidNow.toLocaleString()}</div>
          </div>
          <div>
            <div className="text-xs text-ink/45 uppercase tracking-wide">Trust Score</div>
            <div className="font-mono font-tabular text-xl font-semibold mt-1 text-gold-dark">
              74 {demoScenarioStep >= 5 ? '→ 79' : ''}
            </div>
          </div>
        </div>

        {demoScenarioStep >= 5 && (
          <p className="text-sm text-ink/60 mt-6 leading-relaxed">
            As repayments came in, the outstanding balance dropped, the repayment history improved, and the trust
            score rose from 74 to 79 — which in turn increases the available credit Demo Beverage Company can
            extend on the next cycle.
          </p>
        )}

        <button onClick={resetDemoScenario} className="mt-8 w-full bg-ink text-white text-sm font-medium py-2.5 rounded-sm hover:bg-ink-light transition-colors">
          Close
        </button>
      </div>
    </div>
  );
}

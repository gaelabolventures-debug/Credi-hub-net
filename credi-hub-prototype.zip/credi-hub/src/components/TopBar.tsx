import { Sparkles } from 'lucide-react';
import { useAppState } from '../context/AppState';

export function TopBar({ title, subtitle }: { title: string; subtitle?: string }) {
  const { runDemoScenario, demoScenarioActive } = useAppState();
  return (
    <div className="flex items-center justify-between px-8 py-6 border-b border-line bg-paper/80 backdrop-blur-sm sticky top-0 z-20">
      <div>
        <h1 className="font-display text-2xl text-ink font-semibold">{title}</h1>
        {subtitle && <p className="text-sm text-ink/50 font-sans mt-0.5">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-3">
        <span className="hidden sm:inline-flex items-center gap-1.5 text-xs font-sans font-medium text-gold-dark bg-[#F6EBD9] px-2.5 py-1.5 rounded-sm">
          <span className="w-1.5 h-1.5 rounded-full bg-gold-dark" /> DEMO MODE
        </span>
        <button
          onClick={runDemoScenario}
          disabled={demoScenarioActive}
          className="inline-flex items-center gap-1.5 bg-ink text-white text-sm font-sans font-medium px-3.5 py-2 rounded-sm hover:bg-ink-light transition-colors disabled:opacity-50"
        >
          <Sparkles size={15} /> Load Demo Scenario
        </button>
      </div>
    </div>
  );
}

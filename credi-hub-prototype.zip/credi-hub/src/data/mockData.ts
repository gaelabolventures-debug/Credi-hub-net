import type {
  Business,
  Supplier,
  CreditAgreement,
  Transaction,
  Repayment,
  CreditRequest,
  AppNotification,
  TrustComponent,
  TrustFactor,
} from '../types';

// ---------------------------------------------------------------------------
// All figures below are fictional demo data for prototype purposes only.
// Financial totals are DERIVED from the transaction seeds so the dashboards
// can never show numbers that don't reconcile with each other.
// ---------------------------------------------------------------------------

const TRUST_WEIGHTS = {
  repayment_consistency: 35,
  sales_activity: 25,
  credit_utilization: 15,
  payment_history: 15,
  business_stability: 10,
};

interface BusinessProfileSeed {
  id: string;
  name: string;
  industry: string;
  city: string;
  yearsOperating: number;
  monthlySales: number;
  componentScores: { repayment_consistency: number; sales_activity: number; credit_utilization: number; payment_history: number; business_stability: number };
  trustPrevScore: number;
  trustFactors: TrustFactor[];
}

interface SupplierProfileSeed {
  id: string;
  name: string;
  category: string;
  city: string;
  yearsOperating: number;
}

interface AgreementSeed {
  id: string;
  supplierId: string;
  businessId: string;
  creditLimit: number;
  allocationPct: number;
  status: 'active' | 'overdue' | 'closed';
  startDate: string;
  nextExpectedRepayment: string;
  overdueAmount: number;
  transactions: { date: string; amount: number }[];
}

export const supplierProfiles: SupplierProfileSeed[] = [
  { id: 'SUP-01', name: 'Demo Beverage Company', category: 'Beverage Manufacturing', city: 'Addis Ababa', yearsOperating: 14 },
  { id: 'SUP-02', name: 'Abay Agro Processing', category: 'Agro-Processing & FMCG', city: 'Bahir Dar', yearsOperating: 9 },
  { id: 'SUP-03', name: 'Sheba Construction Supplies', category: 'Building Materials', city: 'Addis Ababa', yearsOperating: 11 },
  { id: 'SUP-04', name: 'Merkato Textile Mills', category: 'Textile & Garment', city: 'Addis Ababa', yearsOperating: 17 },
  { id: 'SUP-05', name: 'Highland Packaging Ltd', category: 'Packaging & Industrial Inputs', city: 'Adama', yearsOperating: 7 },
];

export const businessProfiles: BusinessProfileSeed[] = [
  {
    id: 'BUS-01', name: 'Addis Fresh Distribution', industry: 'FMCG Distribution', city: 'Addis Ababa', yearsOperating: 8, monthlySales: 1850000,
    componentScores: { repayment_consistency: 88, sales_activity: 80, credit_utilization: 62, payment_history: 90, business_stability: 75 },
    trustPrevScore: 74,
    trustFactors: [
      { text: 'Consistent repayments across the last 6 cycles', positive: true },
      { text: 'Strong, steady transaction activity', positive: true },
      { text: 'Low overdue balance', positive: true },
      { text: 'High recent credit utilization', positive: false },
    ],
  },
  {
    id: 'BUS-02', name: 'Habesha Retail Group', industry: 'Retail Chain', city: 'Addis Ababa', yearsOperating: 12, monthlySales: 2400000,
    componentScores: { repayment_consistency: 81, sales_activity: 86, credit_utilization: 55, payment_history: 84, business_stability: 88 },
    trustPrevScore: 78,
    trustFactors: [
      { text: 'Long operating history and stable footprint', positive: true },
      { text: 'High sales volume relative to credit extended', positive: true },
      { text: 'One late repayment in the last quarter', positive: false },
    ],
  },
  {
    id: 'BUS-03', name: 'Green Valley Processors', industry: 'Food Processing', city: 'Hawassa', yearsOperating: 5, monthlySales: 970000,
    componentScores: { repayment_consistency: 60, sales_activity: 58, credit_utilization: 78, payment_history: 65, business_stability: 55 },
    trustPrevScore: 61,
    trustFactors: [
      { text: 'Repayments trending later each cycle', positive: false },
      { text: 'High credit utilization relative to limit', positive: false },
      { text: 'Sales activity growing quarter over quarter', positive: true },
    ],
  },
  {
    id: 'BUS-04', name: 'Abyssinia Wholesale Traders', industry: 'Wholesale Trade', city: 'Addis Ababa', yearsOperating: 15, monthlySales: 3100000,
    componentScores: { repayment_consistency: 92, sales_activity: 90, credit_utilization: 48, payment_history: 94, business_stability: 90 },
    trustPrevScore: 85,
    trustFactors: [
      { text: 'Excellent repayment consistency over 15 years trading', positive: true },
      { text: 'Low utilization relative to approved limit', positive: true },
      { text: 'Very strong transaction volume', positive: true },
    ],
  },
  {
    id: 'BUS-05', name: 'Rift Valley Café Group', industry: 'Café & Hospitality', city: 'Addis Ababa', yearsOperating: 4, monthlySales: 610000,
    componentScores: { repayment_consistency: 70, sales_activity: 62, credit_utilization: 70, payment_history: 72, business_stability: 58 },
    trustPrevScore: 66,
    trustFactors: [
      { text: 'Repayment behavior improving each month', positive: true },
      { text: 'Shorter operating history than portfolio average', positive: false },
      { text: 'Moderate but rising sales activity', positive: true },
    ],
  },
  {
    id: 'BUS-06', name: 'Dire Dawa Grocers Union', industry: 'Retail Cooperative', city: 'Dire Dawa', yearsOperating: 10, monthlySales: 1420000,
    componentScores: { repayment_consistency: 75, sales_activity: 71, credit_utilization: 60, payment_history: 78, business_stability: 80 },
    trustPrevScore: 73,
    trustFactors: [
      { text: 'Cooperative structure adds repayment stability', positive: true },
      { text: 'Sales activity steady but not growing', positive: false },
      { text: 'Clean repayment history', positive: true },
    ],
  },
  {
    id: 'BUS-07', name: 'Blue Nile Construction Retail', industry: 'Building Materials Retail', city: 'Bahir Dar', yearsOperating: 6, monthlySales: 1180000,
    componentScores: { repayment_consistency: 52, sales_activity: 64, credit_utilization: 85, payment_history: 55, business_stability: 60 },
    trustPrevScore: 58,
    trustFactors: [
      { text: 'Overdue balance on current cycle', positive: false },
      { text: 'High credit utilization near approved limit', positive: false },
      { text: 'Sales activity holding steady', positive: true },
    ],
  },
  {
    id: 'BUS-08', name: 'Kaffa Roasters & Distributors', industry: 'Coffee Distribution', city: 'Jimma', yearsOperating: 9, monthlySales: 1650000,
    componentScores: { repayment_consistency: 84, sales_activity: 79, credit_utilization: 58, payment_history: 86, business_stability: 76 },
    trustPrevScore: 77,
    trustFactors: [
      { text: 'Consistent repayments through export season', positive: true },
      { text: 'Strong seasonal transaction activity', positive: true },
      { text: 'Utilization slightly elevated ahead of harvest', positive: false },
    ],
  },
  {
    id: 'BUS-09', name: 'Lalibela Home Goods', industry: 'Retail', city: 'Lalibela', yearsOperating: 3, monthlySales: 420000,
    componentScores: { repayment_consistency: 66, sales_activity: 50, credit_utilization: 66, payment_history: 68, business_stability: 48 },
    trustPrevScore: 60,
    trustFactors: [
      { text: 'Newer business with limited repayment history', positive: false },
      { text: 'On-time on all repayments to date', positive: true },
      { text: 'Sales activity below portfolio average', positive: false },
    ],
  },
  {
    id: 'BUS-10', name: 'Adama Manufacturing Supplies', industry: 'Light Manufacturing', city: 'Adama', yearsOperating: 11, monthlySales: 1980000,
    componentScores: { repayment_consistency: 79, sales_activity: 74, credit_utilization: 52, payment_history: 80, business_stability: 82 },
    trustPrevScore: 72,
    trustFactors: [
      { text: 'Repayment consistency improved this quarter', positive: true },
      { text: 'Stable multi-year operating history', positive: true },
      { text: 'Credit utilization within a healthy range', positive: true },
    ],
  },
];

export const agreementSeeds: AgreementSeed[] = [
  { id: 'AGR-001', supplierId: 'SUP-01', businessId: 'BUS-01', creditLimit: 500000, allocationPct: 10, status: 'active', startDate: '2026-03-02', nextExpectedRepayment: '2026-08-21', overdueAmount: 0,
    transactions: [ { date: '2026-08-14', amount: 42500 }, { date: '2026-08-13', amount: 31200 }, { date: '2026-08-10', amount: 58900 } ] },
  { id: 'AGR-002', supplierId: 'SUP-05', businessId: 'BUS-01', creditLimit: 220000, allocationPct: 12, status: 'active', startDate: '2026-04-11', nextExpectedRepayment: '2026-08-24', overdueAmount: 0,
    transactions: [ { date: '2026-08-12', amount: 19800 }, { date: '2026-08-08', amount: 24100 } ] },
  { id: 'AGR-003', supplierId: 'SUP-01', businessId: 'BUS-02', creditLimit: 650000, allocationPct: 8, status: 'active', startDate: '2026-02-18', nextExpectedRepayment: '2026-08-19', overdueAmount: 0,
    transactions: [ { date: '2026-08-14', amount: 18700 }, { date: '2026-08-13', amount: 12400 }, { date: '2026-08-09', amount: 27600 } ] },
  { id: 'AGR-004', supplierId: 'SUP-03', businessId: 'BUS-02', creditLimit: 380000, allocationPct: 10, status: 'active', startDate: '2026-05-06', nextExpectedRepayment: '2026-08-27', overdueAmount: 0,
    transactions: [ { date: '2026-08-11', amount: 33500 }, { date: '2026-08-07', amount: 21900 } ] },
  { id: 'AGR-005', supplierId: 'SUP-02', businessId: 'BUS-03', creditLimit: 300000, allocationPct: 10, status: 'overdue', startDate: '2026-01-22', nextExpectedRepayment: '2026-08-05', overdueAmount: 42000,
    transactions: [ { date: '2026-08-06', amount: 15200 }, { date: '2026-07-29', amount: 11800 } ] },
  { id: 'AGR-006', supplierId: 'SUP-01', businessId: 'BUS-04', creditLimit: 900000, allocationPct: 8, status: 'active', startDate: '2025-11-14', nextExpectedRepayment: '2026-08-22', overdueAmount: 0,
    transactions: [ { date: '2026-08-14', amount: 61200 }, { date: '2026-08-12', amount: 48300 }, { date: '2026-08-09', amount: 55700 }, { date: '2026-08-05', amount: 39900 } ] },
  { id: 'AGR-007', supplierId: 'SUP-01', businessId: 'BUS-05', creditLimit: 180000, allocationPct: 12, status: 'active', startDate: '2026-06-01', nextExpectedRepayment: '2026-08-25', overdueAmount: 0,
    transactions: [ { date: '2026-08-13', amount: 9800 }, { date: '2026-08-10', amount: 7600 } ] },
  { id: 'AGR-008', supplierId: 'SUP-03', businessId: 'BUS-06', creditLimit: 420000, allocationPct: 10, status: 'active', startDate: '2026-03-19', nextExpectedRepayment: '2026-08-23', overdueAmount: 0,
    transactions: [ { date: '2026-08-11', amount: 28400 }, { date: '2026-08-06', amount: 22100 } ] },
  { id: 'AGR-009', supplierId: 'SUP-03', businessId: 'BUS-07', creditLimit: 340000, allocationPct: 10, status: 'overdue', startDate: '2026-02-09', nextExpectedRepayment: '2026-08-04', overdueAmount: 31500,
    transactions: [ { date: '2026-08-03', amount: 16900 }, { date: '2026-07-27', amount: 13200 } ] },
  { id: 'AGR-010', supplierId: 'SUP-02', businessId: 'BUS-08', creditLimit: 480000, allocationPct: 10, status: 'active', startDate: '2026-01-15', nextExpectedRepayment: '2026-08-20', overdueAmount: 0,
    transactions: [ { date: '2026-08-14', amount: 34200 }, { date: '2026-08-12', amount: 29800 }, { date: '2026-08-08', amount: 26400 } ] },
  { id: 'AGR-011', supplierId: 'SUP-04', businessId: 'BUS-09', creditLimit: 150000, allocationPct: 12, status: 'active', startDate: '2026-05-28', nextExpectedRepayment: '2026-08-26', overdueAmount: 0,
    transactions: [ { date: '2026-08-09', amount: 8100 }, { date: '2026-08-04', amount: 6400 } ] },
  { id: 'AGR-012', supplierId: 'SUP-05', businessId: 'BUS-10', creditLimit: 560000, allocationPct: 10, status: 'active', startDate: '2025-12-20', nextExpectedRepayment: '2026-08-21', overdueAmount: 0,
    transactions: [ { date: '2026-08-13', amount: 37200 }, { date: '2026-08-10', amount: 31900 }, { date: '2026-08-06', amount: 28500 } ] },
];

// --- Derivation ------------------------------------------------------------

function computeTrustScore(c: BusinessProfileSeed['componentScores']): number {
  const raw =
    (c.repayment_consistency * TRUST_WEIGHTS.repayment_consistency +
      c.sales_activity * TRUST_WEIGHTS.sales_activity +
      c.credit_utilization * TRUST_WEIGHTS.credit_utilization +
      c.payment_history * TRUST_WEIGHTS.payment_history +
      c.business_stability * TRUST_WEIGHTS.business_stability) /
    100;
  return Math.round(raw);
}

function trustLabel(score: number): string {
  if (score >= 80) return 'Strong';
  if (score >= 65) return 'Good';
  if (score >= 50) return 'Fair';
  return 'Needs attention';
}

export { trustLabel };

const transactions: Transaction[] = [];
const repayments: Repayment[] = [];
const agreements: CreditAgreement[] = [];

let txCounter = 1;
let rpCounter = 1;

agreementSeeds.forEach((seed) => {
  let used = 0;
  let repaid = 0;

  seed.transactions
    .slice()
    .sort((a, b) => (a.date < b.date ? -1 : 1))
    .forEach((t) => {
      const repaymentAmount = Math.round(t.amount * (seed.allocationPct / 100));
      used += t.amount;
      repaid += repaymentAmount;
      transactions.push({
        id: `TXN-${String(txCounter).padStart(4, '0')}`,
        businessId: seed.businessId,
        supplierId: seed.supplierId,
        date: t.date,
        amount: t.amount,
        type: 'Sale',
        repaymentAllocationPct: seed.allocationPct,
        repaymentAmount,
        remainingBalanceAfter: used - repaid,
      });
      repayments.push({
        id: `RPY-${String(rpCounter).padStart(4, '0')}`,
        agreementId: seed.id,
        businessId: seed.businessId,
        supplierId: seed.supplierId,
        date: t.date,
        amount: repaymentAmount,
        method: 'Sales allocation',
      });
      txCounter++;
      rpCounter++;
    });

  const remaining = seed.creditLimit - used;
  const repaymentRatePct = used > 0 ? Math.round((repaid / used) * 100) : 0;

  agreements.push({
    id: seed.id,
    supplierId: seed.supplierId,
    businessId: seed.businessId,
    creditLimit: seed.creditLimit,
    used,
    remaining,
    repaymentAllocationPct: seed.allocationPct,
    repaymentRate: repaymentRatePct,
    status: seed.status,
    startDate: seed.startDate,
    nextExpectedRepayment: seed.nextExpectedRepayment,
    overdueAmount: seed.overdueAmount,
  });
});

export { transactions, repayments, agreements };

// --- Businesses --------------------------------------------------------

export const businesses: Business[] = businessProfiles.map((p) => {
  const myAgreements = agreements.filter((a) => a.businessId === p.id);
  const totalCreditLimit = myAgreements.reduce((s, a) => s + a.creditLimit, 0);
  const totalUsed = myAgreements.reduce((s, a) => s + a.used, 0);
  const repaidSum = myAgreements.reduce((s, a) => s + Math.round((a.used * a.repaymentRate) / 100), 0);
  const outstanding = totalUsed - repaidSum;
  const repaymentRate = totalUsed > 0 ? Math.round((repaidSum / totalUsed) * 100) : 0;
  const status = myAgreements.some((a) => a.status === 'overdue') ? 'overdue' : 'active';
  const trustComponents: TrustComponent[] = [
    { label: 'Repayment consistency', weight: TRUST_WEIGHTS.repayment_consistency, score: p.componentScores.repayment_consistency },
    { label: 'Sales activity', weight: TRUST_WEIGHTS.sales_activity, score: p.componentScores.sales_activity },
    { label: 'Credit utilization', weight: TRUST_WEIGHTS.credit_utilization, score: p.componentScores.credit_utilization },
    { label: 'Payment history', weight: TRUST_WEIGHTS.payment_history, score: p.componentScores.payment_history },
    { label: 'Business stability', weight: TRUST_WEIGHTS.business_stability, score: p.componentScores.business_stability },
  ];

  return {
    id: p.id,
    name: p.name,
    industry: p.industry,
    yearsOperating: p.yearsOperating,
    city: p.city,
    monthlySales: p.monthlySales,
    trustScore: computeTrustScore(p.componentScores),
    trustPrevScore: p.trustPrevScore,
    trustComponents,
    trustFactors: p.trustFactors,
    totalCreditLimit,
    outstanding,
    repaid: repaidSum,
    repaymentRate,
    status,
    supplierIds: Array.from(new Set(myAgreements.map((a) => a.supplierId))),
  };
});

// --- Suppliers -----------------------------------------------------------

export const suppliers: Supplier[] = supplierProfiles.map((p) => {
  const myAgreements = agreements.filter((a) => a.supplierId === p.id);
  const totalFinanced = myAgreements.reduce((s, a) => s + a.creditLimit, 0);
  const repaidSum = myAgreements.reduce((s, a) => s + Math.round((a.used * a.repaymentRate) / 100), 0);
  const totalUsed = myAgreements.reduce((s, a) => s + a.used, 0);
  const totalOutstanding = totalUsed - repaidSum;
  const overdueAmount = myAgreements.reduce((s, a) => s + a.overdueAmount, 0);
  const avgRepaymentRate = myAgreements.length > 0 ? Math.round(myAgreements.reduce((s, a) => s + a.repaymentRate, 0) / myAgreements.length) : 0;
  const overdueRatio = totalOutstanding > 0 ? overdueAmount / totalOutstanding : 0;
  const portfolioRisk: Supplier['portfolioRisk'] = overdueRatio > 0.15 ? 'Elevated' : overdueRatio > 0.05 ? 'Moderate' : 'Low';

  return {
    id: p.id,
    name: p.name,
    category: p.category,
    city: p.city,
    yearsOperating: p.yearsOperating,
    totalFinanced,
    totalOutstanding,
    totalRepaid: repaidSum,
    overdueAmount,
    avgRepaymentRate,
    portfolioRisk,
    businessIds: Array.from(new Set(myAgreements.map((a) => a.businessId))),
  };
});

// --- Platform-level totals -------------------------------------------------

export const platformMetrics = {
  totalSupplierCredit: agreements.reduce((s, a) => s + a.creditLimit, 0),
  outstanding: businesses.reduce((s, b) => s + b.outstanding, 0),
  repaid: businesses.reduce((s, b) => s + b.repaid, 0),
  availableCredit: agreements.reduce((s, a) => s + a.remaining, 0),
  get repaymentRate() {
    const usedTotal = agreements.reduce((s, a) => s + a.used, 0);
    return usedTotal > 0 ? Math.round((this.repaid / usedTotal) * 100) : 0;
  },
  get trustScore() {
    return Math.round(businesses.reduce((s, b) => s + b.trustScore, 0) / businesses.length);
  },
};

// --- Credit requests (workflow demo) ---------------------------------------

export const creditRequests: CreditRequest[] = [
  { id: 'REQ-101', businessId: 'BUS-01', supplierId: 'SUP-01', requestedAmount: 750000, purpose: 'Expand distribution capacity ahead of holiday season', expectedMonthlySales: 2400000, preferredRepaymentPeriodMonths: 6, status: 'under_review', submittedDate: '2026-08-12' },
  { id: 'REQ-102', businessId: 'BUS-05', supplierId: 'SUP-01', requestedAmount: 120000, purpose: 'Stock additional beverage inventory for new outlet', expectedMonthlySales: 780000, preferredRepaymentPeriodMonths: 4, status: 'info_requested', submittedDate: '2026-08-09' },
  { id: 'REQ-103', businessId: 'BUS-08', supplierId: 'SUP-02', requestedAmount: 260000, purpose: 'Bridge working capital during harvest procurement', expectedMonthlySales: 1900000, preferredRepaymentPeriodMonths: 5, status: 'under_review', submittedDate: '2026-08-13' },
  { id: 'REQ-104', businessId: 'BUS-04', supplierId: 'SUP-01', requestedAmount: 400000, purpose: 'Increase warehouse stock for regional expansion', expectedMonthlySales: 3400000, preferredRepaymentPeriodMonths: 6, status: 'approved', submittedDate: '2026-07-28' },
  { id: 'REQ-105', businessId: 'BUS-07', supplierId: 'SUP-03', requestedAmount: 300000, purpose: 'Additional cement and rebar stock', expectedMonthlySales: 1100000, preferredRepaymentPeriodMonths: 5, status: 'rejected', submittedDate: '2026-07-30', additionalInfo: 'Existing overdue balance on current line' },
  { id: 'REQ-106', businessId: 'BUS-09', supplierId: 'SUP-04', requestedAmount: 90000, purpose: 'Seasonal inventory build for tourist season', expectedMonthlySales: 480000, preferredRepaymentPeriodMonths: 3, status: 'under_review', submittedDate: '2026-08-14' },
];

// --- Notifications -----------------------------------------------------

export const notifications: AppNotification[] = [
  { id: 'NTF-01', type: 'repayment_received', message: 'Repayment of ETB 61,200 × allocation received from Abyssinia Wholesale Traders', date: '2026-08-14', read: false, audience: 'supplier' },
  { id: 'NTF-02', type: 'trust_updated', message: 'Trust Score updated for Addis Fresh Distribution: 74 → 79', date: '2026-08-14', read: false, audience: 'supplier' },
  { id: 'NTF-03', type: 'credit_approved', message: 'Your credit request with Demo Beverage Company was approved', date: '2026-08-01', read: true, audience: 'business' },
  { id: 'NTF-04', type: 'repayment_upcoming', message: 'Repayment approaching for your line with Sheba Construction Supplies — due Aug 23', date: '2026-08-13', read: false, audience: 'business' },
  { id: 'NTF-05', type: 'limit_increased', message: 'Credit limit increased to ETB 900,000 for Abyssinia Wholesale Traders', date: '2026-08-01', read: true, audience: 'supplier' },
  { id: 'NTF-06', type: 'info_requested', message: 'Demo Beverage Company requested additional information on your credit request', date: '2026-08-09', read: false, audience: 'business' },
  { id: 'NTF-07', type: 'repayment_received', message: 'Repayment received from Kaffa Roasters & Distributors', date: '2026-08-14', read: true, audience: 'supplier' },
  { id: 'NTF-08', type: 'trust_updated', message: 'Trust Score updated for Blue Nile Construction Retail: 62 → 58', date: '2026-08-04', read: true, audience: 'supplier' },
  { id: 'NTF-09', type: 'repayment_upcoming', message: 'Repayment approaching on your Highland Packaging line — due Aug 24', date: '2026-08-12', read: false, audience: 'business' },
  { id: 'NTF-10', type: 'credit_approved', message: 'New credit agreement created with Abyssinia Wholesale Traders', date: '2026-07-28', read: true, audience: 'admin' },
];

export const findBusiness = (id: string) => businesses.find((b) => b.id === id);
export const findSupplier = (id: string) => suppliers.find((s) => s.id === id);
export const agreementsForBusiness = (businessId: string) => agreements.filter((a) => a.businessId === businessId);
export const agreementsForSupplier = (supplierId: string) => agreements.filter((a) => a.supplierId === supplierId);
export const transactionsForBusiness = (businessId: string) => transactions.filter((t) => t.businessId === businessId);
export const transactionsForSupplier = (supplierId: string) => transactions.filter((t) => t.supplierId === supplierId);
export const repaymentsForBusiness = (businessId: string) => repayments.filter((r) => r.businessId === businessId);
export const repaymentsForSupplier = (supplierId: string) => repayments.filter((r) => r.supplierId === supplierId);
